Seed archive for chat and post UI tests.
