

export default function ChatListItem({ chat, active, onClick }: { chat: Chat; active: boolean; onClick: () => void }) {
  const lastText = chat.lastMessage?.content || chat.lastMessage?.attachments[0]?.file.filename || 'Пока нет сообщений'

  return (
    <button
      onClick={onClick}
      className={`flex min-h-16 w-full items-center gap-3 rounded-2xl p-3 text-left transition ${active ? 'bg-violet-50' : 'hover:bg-zinc-50'
        }`}
    >
      <Avatar title={chat.title} src={chat.avatarUrl} />
      <span className="min-w-0 flex-1">
        <span className="flex items-center justify-between gap-2">
          <span className="truncate text-sm font-bold text-slate-900">{chat.title}</span>
          <span className="shrink-0 text-[11px] text-zinc-400">{formatTime(chat.lastMessageAt)}</span>
        </span>
        <span className="mt-1 block truncate text-xs text-zinc-500">{lastText}</span>
      </span>
      {chat.unreadCount > 0 && (
        <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-violet-600 px-1.5 text-[11px] font-bold text-white">
          {chat.unreadCount}
        </span>
      )}
    </button>
  )
}