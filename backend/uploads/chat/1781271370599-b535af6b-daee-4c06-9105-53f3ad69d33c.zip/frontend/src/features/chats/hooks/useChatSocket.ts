'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { io, Socket } from 'socket.io-client'
import { useQueryClient } from '@tanstack/react-query'
import { useAuth } from '@/features/auth/providers/AuthProvider'
import { chatQueryKeys } from '../api/chats.queries'
import type { ChatMessage, TypingUser } from '../types/chat.types'

const API_URL = process.env.NEXT_PUBLIC_API_URL?.replace(/\/api$/, '')

type ServerToClientEvents = {
  'message:new': (message: ChatMessage) => void
  'message:updated': (message: ChatMessage) => void
  'message:read': (payload: { chatId: string; messageId?: string; userId: string; readAt: string }) => void
  typing: (payload: { chatId: string; user: TypingUser; isTyping: boolean }) => void
  'presence:changed': (payload: { userId: string; isOnline: boolean; lastSeenAt: string }) => void
}

type ClientToServerEvents = {
  'chat:join': (payload: { chatId: string }) => void
  typing: (payload: { chatId: string; isTyping: boolean }) => void
  'message:read': (payload: { chatId: string; messageId?: string }) => void
}

export function useChatSocket(activeChatId: string | null) {
  const { accessToken } = useAuth()
  const queryClient = useQueryClient()
  const socketRef = useRef<Socket<ServerToClientEvents, ClientToServerEvents> | null>(null)
  const [typingUsers, setTypingUsers] = useState<TypingUser[]>([])
  const typingTimeoutsRef = useRef<Map<string, number>>(new Map())

  useEffect(() => {
    if (!accessToken || !API_URL) {
      return
    }

    const socket: Socket<ServerToClientEvents, ClientToServerEvents> = io(`${API_URL}/chats`, {
      auth: { accessToken },
      transports: ['websocket'],
      withCredentials: true,
    })

    socketRef.current = socket

    socket.on('message:new', (message) => {
      queryClient.invalidateQueries({ queryKey: chatQueryKeys.lists() })
      queryClient.invalidateQueries({ queryKey: chatQueryKeys.messages(message.chatId) })
      queryClient.invalidateQueries({ queryKey: chatQueryKeys.attachments(message.chatId) })
    })

    socket.on('message:updated', (message) => {
      queryClient.invalidateQueries({ queryKey: chatQueryKeys.messages(message.chatId) })
      queryClient.invalidateQueries({ queryKey: chatQueryKeys.pinned(message.chatId) })
    })

    socket.on('message:read', (payload) => {
      queryClient.invalidateQueries({ queryKey: chatQueryKeys.messages(payload.chatId) })
    })

    socket.on('typing', (payload) => {
      if (!payload.isTyping) {
        setTypingUsers((users) => users.filter((user) => user.id !== payload.user.id))
        return
      }

      setTypingUsers((users) => {
        if (users.some((user) => user.id === payload.user.id)) {
          return users
        }

        return [...users, payload.user]
      })

      const oldTimeout = typingTimeoutsRef.current.get(payload.user.id)
      if (oldTimeout) {
        window.clearTimeout(oldTimeout)
      }

      const timeoutId = window.setTimeout(() => {
        setTypingUsers((users) => users.filter((user) => user.id !== payload.user.id))
        typingTimeoutsRef.current.delete(payload.user.id)
      }, 2200)

      typingTimeoutsRef.current.set(payload.user.id, timeoutId)
    })

    socket.on('presence:changed', () => {
      queryClient.invalidateQueries({ queryKey: chatQueryKeys.lists() })
    })

    return () => {
      socket.disconnect()
      socketRef.current = null
      typingTimeoutsRef.current.forEach((timeoutId) => window.clearTimeout(timeoutId))
      typingTimeoutsRef.current.clear()
    }
  }, [accessToken, queryClient])

  useEffect(() => {
    if (!activeChatId) {
      return
    }

    socketRef.current?.emit('chat:join', { chatId: activeChatId })
  }, [activeChatId])

  return useMemo(
    () => ({
      typingUsers,
      sendTyping(isTyping: boolean) {
        if (!activeChatId) {
          return
        }

        socketRef.current?.emit('typing', { chatId: activeChatId, isTyping })
      },
      markRead(messageId?: string) {
        if (!activeChatId) {
          return
        }

        socketRef.current?.emit('message:read', { chatId: activeChatId, messageId })
      },
    }),
    [activeChatId, typingUsers],
  )
}
