import type {
  AttachmentsResponse,
  Chat,
  ChatsResponse,
  CreateMessagePayload,
  FileAssetType,
  MembersResponse,
  MessagesResponse,
  SearchIn,
} from '../types/chat.types'

const API_URL = process.env.NEXT_PUBLIC_API_URL

type ApiErrorBody = {
  message?: string | string[]
  error?: string
}

async function apiRequest<T>(
  path: string,
  accessToken: string,
  options: RequestInit = {},
): Promise<T> {
  const response = await fetch(`${API_URL}${path}`, {
    ...options,
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`,
      ...options.headers,
    },
  })

  if (!response.ok) {
    let errorMessage = 'Request failed'

    try {
      const errorBody = (await response.json()) as ApiErrorBody

      if (Array.isArray(errorBody.message)) {
        errorMessage = errorBody.message.join(', ')
      } else if (errorBody.message) {
        errorMessage = errorBody.message
      } else if (errorBody.error) {
        errorMessage = errorBody.error
      }
    } catch {
      errorMessage = response.statusText
    }

    throw new Error(errorMessage)
  }

  return response.json() as Promise<T>
}

function buildQuery(params: Record<string, string | number | undefined>) {
  const query = new URLSearchParams()

  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== '') {
      query.set(key, String(value))
    }
  }

  const queryString = query.toString()
  return queryString ? `?${queryString}` : ''
}

export const chatsApi = {
  getChats(
    accessToken: string,
    params: { search?: string; searchIn?: SearchIn; page?: number; limit?: number },
  ) {
    return apiRequest<ChatsResponse>(`/chats${buildQuery(params)}`, accessToken)
  },

  getMessages(accessToken: string, chatId: string) {
    return apiRequest<MessagesResponse>(`/chats/${chatId}/messages`, accessToken)
  },

  getPinnedMessages(accessToken: string, chatId: string) {
    return apiRequest<MessagesResponse>(`/chats/${chatId}/pinned`, accessToken)
  },

  getMembers(accessToken: string, chatId: string) {
    return apiRequest<MembersResponse>(`/chats/${chatId}/members`, accessToken)
  },

  getAttachments(accessToken: string, chatId: string, type?: FileAssetType) {
    return apiRequest<AttachmentsResponse>(
      `/chats/${chatId}/attachments${buildQuery({ type })}`,
      accessToken,
    )
  },

  createMessage(accessToken: string, payload: CreateMessagePayload) {
    const { chatId, ...body } = payload
    return apiRequest(`/chats/${chatId}/messages`, accessToken, {
      method: 'POST',
      body: JSON.stringify(body),
    })
  },

  toggleReaction(accessToken: string, chatId: string, messageId: string, emoji: '👍' | '👎' | '🔥' | '❤️' | '😡') {
    return apiRequest(`/chats/${chatId}/messages/${messageId}/reactions/toggle`, accessToken, {
      method: 'POST',
      body: JSON.stringify({ emoji }),
    })
  },

  markAsRead(accessToken: string, chatId: string, messageId?: string) {
    return apiRequest<{ success: true }>(`/chats/${chatId}/read`, accessToken, {
      method: 'POST',
      body: JSON.stringify({ messageId }),
    })
  },

  toggleNotifications(accessToken: string, chatId: string, enabled: boolean) {
    return apiRequest<{ success: true }>(`/chats/${chatId}/notifications`, accessToken, {
      method: 'PATCH',
      body: JSON.stringify({ enabled }),
    })
  },

  leaveOrDeleteChat(accessToken: string, chatId: string) {
    return apiRequest<{ success: true }>(`/chats/${chatId}`, accessToken, {
      method: 'DELETE',
    })
  },

  updateMemberRole(accessToken: string, chatId: string, userId: string, role: 'ADMIN' | 'MEMBER') {
    return apiRequest<MembersResponse>(`/chats/${chatId}/members/${userId}/role`, accessToken, {
      method: 'PATCH',
      body: JSON.stringify({ role }),
    })
  },

  removeMember(accessToken: string, chatId: string, userId: string) {
    return apiRequest<MembersResponse>(`/chats/${chatId}/members/${userId}`, accessToken, {
      method: 'DELETE',
    })
  },

  inviteMembers(accessToken: string, chatId: string, memberIds: string[]) {
    return apiRequest<MembersResponse>(`/chats/${chatId}/members/invite`, accessToken, {
      method: 'POST',
      body: JSON.stringify({ memberIds }),
    })
  },

  deleteMessage(accessToken: string, chatId: string, messageId: string) {
    return apiRequest(`/chats/${chatId}/messages/${messageId}`, accessToken, {
      method: 'DELETE',
    })
  },

  pinMessage(accessToken: string, chatId: string, messageId: string) {
    return apiRequest(`/chats/${chatId}/messages/${messageId}/pin`, accessToken, {
      method: 'POST',
    })
  },

  unpinMessage(accessToken: string, chatId: string, messageId: string) {
    return apiRequest(`/chats/${chatId}/messages/${messageId}/unpin`, accessToken, {
      method: 'POST',
    })
  },

  createGroup(accessToken: string, payload: { title: string; memberIds: string[] }) {
    return apiRequest<Chat>('/chats/groups', accessToken, {
      method: 'POST',
      body: JSON.stringify(payload),
    })
  },
}
