'use client'

import { FormEvent, ReactNode, RefCallback, useCallback, useEffect, useMemo, useRef, useState } from 'react'
import {
  Archive,
  CheckCheck,
  ChevronLeft,
  ChevronRight,
  File,
  Image as ImageIcon,
  Mic,
  MoreVertical,
  Paperclip,
  Pin,
  Search,
  Send,
  Smile,
  Users,
  Video,
  Volume2,
  X,
} from 'lucide-react'
import { useParams, useRouter } from 'next/navigation'
import { useAuth } from '@/features/auth/providers/AuthProvider'
import { useFriendsQuery, useSubscriptionsQuery } from '@/features/social/api/social.queries'
import type { SocialUserCard, SubscriptionItem } from '@/features/social/types/social.types'
import {
  useChatActionMutations,
  useChatAttachmentsQuery,
  useChatMembersQuery,
  useChatMessagesQuery,
  useChatsQuery,
  useCreateGroupChatMutation,
  useCreateMessageMutation,
  usePinnedMessagesQuery,
} from '../api/chats.queries'
import { useChatSocket } from '../hooks/useChatSocket'
import type { Chat, ChatMessage, FileAssetType, SearchIn } from '../types/chat.types'

type ChatView = 'chat' | 'members' | 'attachments'
type AttachmentTab = FileAssetType | 'LINKS'

type ReactionEmoji = '👍' | '👎' | '🔥' | '❤️' | '😡'

const attachmentTabs: { label: string; value: AttachmentTab }[] = [
  { label: 'Фото', value: 'IMAGE' },
  { label: 'Видео', value: 'VIDEO' },
  { label: 'Аудиофайлы', value: 'AUDIO' },
  { label: 'Файлы', value: 'FILE' },
  { label: 'Архивы', value: 'ARCHIVE' },
  { label: 'Ссылки', value: 'LINKS' },
]

const emojiOptions = ['😀', '😂', '😍', '😎', '🤝', '❤️', '🤬', '🍷', '🔥', '✨']
const reactionOptions: ReactionEmoji[] = ['👍', '👎', '🔥', '❤️', '😡']

function initials(value: string) {
  return value.slice(0, 2).toUpperCase()
}

function formatTime(value: string | null | undefined) {
  if (!value) {
    return ''
  }

  return new Intl.DateTimeFormat('ru-RU', {
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(value))
}

function formatLastSeen(value: string | null | undefined) {
  if (!value) {
    return 'был(а) давно'
  }

  return `был(а) ${new Intl.DateTimeFormat('ru-RU', {
    day: '2-digit',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(value))}`
}

function createChatSlug(chat: Chat) {
  const value = chat.type === 'DIRECT'
    ? chat.directUser?.username ?? chat.title
    : chat.title

  return value
    .trim()
    .replace(/\s+/g, '-')
    .replace(/[^\p{L}\p{N}_-]+/gu, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '') || 'chat'
}

function createChatHref(chat: Chat) {
  return `/messages/${encodeURIComponent(createChatSlug(chat))}`
}

function getParamString(value: string | string[] | undefined) {
  return Array.isArray(value) ? value[0] : value
}

function isUserOnline(value: string | null | undefined) {
  if (!value) {
    return false
  }

  return Date.now() - new Date(value).getTime() < 1000 * 60 * 5
}

function Avatar({ title, src, size = 'md' }: { title: string; src?: string | null; size?: 'sm' | 'md' | 'lg' }) {
  const sizeClass = size === 'lg' ? 'h-14 w-14 text-lg' : size === 'sm' ? 'h-9 w-9 text-xs' : 'h-11 w-11 text-sm'

  if (src) {
    return <img src={src} alt={title} className={`${sizeClass} rounded-full object-cover`} />
  }

  return (
    <div className={`${sizeClass} flex shrink-0 items-center justify-center rounded-full bg-violet-100 font-bold text-violet-600`}>
      {initials(title)}
    </div>
  )
}

function useDismissibleLayer<T extends HTMLElement>(isOpen: boolean, onClose: () => void) {
  const ref = useRef<T | null>(null)

  useEffect(() => {
    if (!isOpen) {
      return
    }

    function handlePointerDown(event: Event) {
      const target = event.target as Node | null

      if (target && ref.current && !ref.current.contains(target)) {
        onClose()
      }
    }

    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        onClose()
      }
    }

    document.addEventListener('mousedown', handlePointerDown, true)
    document.addEventListener('touchstart', handlePointerDown, true)
    document.addEventListener('keydown', handleKeyDown)

    return () => {
      document.removeEventListener('mousedown', handlePointerDown, true)
      document.removeEventListener('touchstart', handlePointerDown, true)
      document.removeEventListener('keydown', handleKeyDown)
    }
  }, [isOpen, onClose])

  return ref
}

export function MessagesPageContent() {
  const { user } = useAuth()
  const router = useRouter()
  const params = useParams()
  const routeChatSlug = decodeURIComponent(getParamString(params.chatSlug) ?? '')
  const [search, setSearch] = useState('')
  const [searchIn, setSearchIn] = useState<SearchIn>('all')
  const [page, setPage] = useState(1)
  const [activeChatId, setActiveChatId] = useState<string | null>(null)
  const [activeChatSnapshot, setActiveChatSnapshot] = useState<Chat | null>(null)
  const [focusMessageId, setFocusMessageId] = useState<string | null>(null)
  const [view, setView] = useState<ChatView>('chat')
  const [attachmentType, setAttachmentType] = useState<AttachmentTab>('IMAGE')
  const [groupModalOpen, setGroupModalOpen] = useState(false)

  const chatsQuery = useChatsQuery({ search, searchIn, page, limit: 10 })
  const chats = chatsQuery.data?.items ?? []
  const meta = chatsQuery.data?.meta
  const chatFromCurrentPage = activeChatId
    ? chats.find((chat) => chat.id === activeChatId) ?? null
    : null
  const activeChat = chatFromCurrentPage ?? (activeChatSnapshot?.id === activeChatId ? activeChatSnapshot : null)

  useEffect(() => {
    setPage(1)
  }, [search, searchIn])

  useEffect(() => {
    if (chatFromCurrentPage) {
      setActiveChatSnapshot(chatFromCurrentPage)
    }
  }, [chatFromCurrentPage])

  useEffect(() => {
    if (!routeChatSlug || chats.length === 0) {
      return
    }

    const chatFromRoute = chats.find((chat) => createChatSlug(chat) === routeChatSlug)

    if (chatFromRoute && chatFromRoute.id !== activeChatId) {
      setActiveChatId(chatFromRoute.id)
      setActiveChatSnapshot(chatFromRoute)
      setFocusMessageId(chatFromRoute.matchedMessage?.id ?? null)
      setView('chat')
    }
  }, [activeChatId, chats, routeChatSlug])

  const handleSelectChat = useCallback((chat: Chat) => {
    setActiveChatId(chat.id)
    setActiveChatSnapshot(chat)
    setFocusMessageId(chat.matchedMessage?.id ?? null)
    setView('chat')
    router.push(createChatHref(chat), { scroll: false })
  }, [router])

  const handleCreatedChat = useCallback((chat: Chat) => {
    setActiveChatId(chat.id)
    setActiveChatSnapshot(chat)
    setFocusMessageId(null)
    setView('chat')
    router.push(createChatHref(chat), { scroll: false })
  }, [router])

  useEffect(() => {
    setView('chat')
  }, [activeChatId])

  const isGroup = activeChat?.type === 'GROUP'
  const emptyChatRows = Math.max(0, 10 - chats.length)

  return (
    <>
      <section className="flex h-[calc(100dvh-9rem)] min-h-[720px] w-full min-w-0 flex-col gap-5 lg:flex-row">
        <aside className="flex min-h-[620px] w-96 max-w-full flex-col overflow-hidden rounded-3xl border border-violet-100/70 bg-white shadow-sm max-lg:w-full lg:h-full">
          <div className="p-[40px]">
            <div className="mb-4 space-y-3">
              <div className="flex items-center justify-between gap-3">
                <h1 className="text-2xl font-bold text-slate-950">Сообщения</h1>
                <button
                  onClick={() => setGroupModalOpen(true)}
                  className="inline-flex items-center justify-center gap-2 rounded-xl border border-violet-300 px-3 py-2 text-xs font-bold text-violet-600 transition hover:bg-violet-50"
                >
                  <Users className="h-4 w-4" />
                  Создать групповой чат
                </button>
              </div>
            </div>

            <div className="flex gap-2">
              <label className="flex h-11 min-w-0 flex-1 items-center gap-2 rounded-xl border border-zinc-200 bg-white px-3 text-sm text-zinc-400">
                <Search className="h-4 w-4 shrink-0" />
                <input
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                  placeholder="Поиск"
                  className="min-w-0 flex-1 bg-transparent text-zinc-900 outline-none placeholder:text-zinc-400"
                />
              </label>

              <select
                value={searchIn}
                onChange={(event) => setSearchIn(event.target.value as SearchIn)}
                className="h-11 w-48 shrink-0 rounded-xl border border-zinc-200 bg-white px-3 text-xs font-semibold text-slate-600 outline-none"
              >
                <option value="all">По всем</option>
                <option value="nicknames">По никнеймам и названиям чата</option>
                <option value="messages">По сообщениям</option>
              </select>
            </div>
            
            <div className="min-h-10 flex-1 overflow-y-auto px-5 pb-5">
              {chatsQuery.isLoading && (
                <p className="py-10 text-center text-sm text-zinc-500">
                  Загружаем чаты...
                </p>
              )}

              {!chatsQuery.isLoading && chats.length === 0 && (
                <p className="py-10 text-center text-sm text-zinc-500">
                  Чаты не найдены
                </p>
              )}

              {!chatsQuery.isLoading && chats.length > 0 && (
                <div className="grid gap-2">
                  {chats.map((chat) => (
                    <ChatListItem
                      key={chat.id}
                      chat={chat}
                      active={chat.id === activeChatId}
                      search={search}
                      searchIn={searchIn}
                      onClick={() => handleSelectChat(chat)}
                    />
                  ))}

                  {Array.from({ length: emptyChatRows }).map((_, index) => (
                    <div
                      key={`empty-chat-row-${index}`}
                      className="h-16 rounded-2xl border border-dashed border-violet-100 bg-violet-50/20"
                    />
                  ))}
                </div>
              )}
            </div>
          </div>



          {meta && meta.totalPages > 1 && (
            <div className="shrink-0 border-t border-zinc-100 p-4">
              <div className="flex items-center justify-between text-xs font-bold text-slate-600">
                <button
                  disabled={page <= 1}
                  onClick={() => setPage((value) => Math.max(1, value - 1))}
                  className="rounded-xl border border-zinc-200 px-3 py-2 disabled:opacity-40"
                >
                  Назад
                </button>

                <span>
                  {page} / {meta.totalPages}
                </span>

                <button
                  disabled={page >= meta.totalPages}
                  onClick={() => setPage((value) => Math.min(meta.totalPages, value + 1))}
                  className="rounded-xl border border-zinc-200 px-3 py-2 disabled:opacity-40"
                >
                  Вперед
                </button>
              </div>
            </div>
          )}
        </aside>

        <main className="flex min-h-[620px] min-w-0 flex-1 flex-col overflow-hidden rounded-3xl border border-violet-100/70 bg-white shadow-sm lg:h-full">
          {!activeChat && (
            <div className="flex min-h-0 flex-1 flex-col items-center justify-center px-6 text-center">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-violet-50 text-violet-600">
                <Users className="h-8 w-8" />
              </div>

              <h2 className="text-xl font-bold text-slate-950">Выберите чат</h2>

              <p className="mt-2 max-w-sm text-sm text-zinc-500">
                Сначала слева выбери личный или групповой чат. После этого переписка откроется здесь.
              </p>
            </div>
          )}

          {activeChat && (
            <div className="flex h-full min-h-0 flex-1 flex-col">
              <div className="shrink-0">
                <ChatHeader
                  chat={activeChat}
                  view={view}
                  setView={setView}
                  isGroup={isGroup}
                />
              </div>

              <div className="min-h-0 flex-1 overflow-hidden">
                {view === 'chat' && (
                  <ChatMessagesView
                    chat={activeChat}
                    currentUserId={user!.id}
                    focusMessageId={focusMessageId}
                    onFocusMessageHandled={() => setFocusMessageId(null)}
                  />
                )}

                {view === 'members' && isGroup && (
                  <ChatMembersView chat={activeChat} />
                )}

                {view === 'attachments' && isGroup && (
                  <ChatAttachmentsView
                    chat={activeChat}
                    attachmentType={attachmentType}
                    setAttachmentType={setAttachmentType}
                  />
                )}
              </div>
            </div>
          )}
        </main>
      </section>

      {groupModalOpen && <CreateGroupChatModal onClose={() => setGroupModalOpen(false)} onCreated={handleCreatedChat} />}
    </>
  )
}

function ChatListItem({
  chat,
  active,
  search,
  searchIn,
  onClick,
}: {
  chat: Chat
  active: boolean
  search: string
  searchIn: SearchIn
  onClick: () => void
}) {
  const shouldShowMatchedMessage = Boolean(search.trim() && searchIn !== 'nicknames' && chat.matchedMessage)
  const previewMessage = shouldShowMatchedMessage ? chat.matchedMessage : chat.lastMessage
  const previewText = previewMessage?.content || previewMessage?.attachments[0]?.file.filename || 'Пока нет сообщений'
  const previewTime = previewMessage?.createdAt ?? chat.lastMessageAt

  return (
    <button
      onClick={onClick}
      className={`flex min-h-16 w-full items-center gap-3 rounded-2xl p-3 text-left transition ${active ? 'bg-violet-50' : 'hover:bg-zinc-50'
        }`}
    >
      <Avatar title={chat.title} src={chat.avatarUrl} />
      <span className="min-w-0 flex-1">
        <span className="flex items-center justify-between gap-2">
          <span className="truncate text-sm font-bold text-slate-900">{chat.title}</span>
          <span className="shrink-0 text-[11px] text-zinc-400">{formatTime(previewTime)}</span>
        </span>
        <span className={`mt-1 block truncate text-xs ${shouldShowMatchedMessage ? 'font-semibold text-violet-600' : 'text-zinc-500'}`}>
          {shouldShowMatchedMessage ? `Найдено: ${previewText}` : previewText}
        </span>
      </span>
      {chat.unreadCount > 0 && (
        <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-violet-600 px-1.5 text-[11px] font-bold text-white">
          {chat.unreadCount}
        </span>
      )}
    </button>
  )
}

function ChatHeader({
  chat,
  view,
  setView,
  isGroup,
}: {
  chat: Chat
  view: ChatView
  setView: (view: ChatView) => void
  isGroup: boolean
}) {
  const actions = useChatActionMutations()
  const [menuOpen, setMenuOpen] = useState(false)
  const menuRef = useDismissibleLayer<HTMLDivElement>(menuOpen, () => setMenuOpen(false))
  const directOnline = isUserOnline(chat.directUser?.lastLoginAt)

  return (
    <header className="relative flex shrink-0 items-center justify-between gap-4 border-b border-zinc-100 px-6 py-4">
      <div className="flex min-w-0 items-center gap-3">
        {view !== 'chat' && (
          <button onClick={() => setView('chat')} className="rounded-full p-2 text-slate-700 hover:bg-zinc-100">
            <ChevronLeft className="h-5 w-5" />
          </button>
        )}
        <Avatar title={chat.title} src={chat.avatarUrl} />
        <div className="min-w-0">
          <h2 className="truncate text-base font-bold text-slate-950">{chat.title}</h2>
          <p className="text-xs font-medium text-zinc-500">
            {isGroup ? `${chat.membersCount} участников` : directOnline ? 'Онлайн' : formatLastSeen(chat.directUser?.lastLoginAt)}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <button className="rounded-full p-2 text-slate-700 hover:bg-zinc-100">
          <Search className="h-5 w-5" />
        </button>
        <div ref={menuRef} className="relative">
          <button onClick={() => setMenuOpen((value) => !value)} className="rounded-full p-2 text-slate-700 hover:bg-zinc-100">
            <MoreVertical className="h-5 w-5" />
          </button>

          {menuOpen && (
            <div className="absolute right-0 top-11 z-20 w-64 rounded-2xl border border-zinc-100 bg-white p-2 text-sm shadow-xl">
              {isGroup && (
                <>
                  <button onClick={() => { setView('members'); setMenuOpen(false) }} className="w-full rounded-xl px-3 py-2 text-left hover:bg-violet-50">
                    Участники чата
                  </button>
                  <button onClick={() => { setView('attachments'); setMenuOpen(false) }} className="w-full rounded-xl px-3 py-2 text-left hover:bg-violet-50">
                    Вложения чата
                  </button>
                </>
              )}
              <button
                onClick={() => { actions.toggleNotifications.mutate({ chatId: chat.id, enabled: !chat.notificationsEnabled }); setMenuOpen(false) }}
                className="w-full rounded-xl px-3 py-2 text-left hover:bg-violet-50"
              >
                {chat.notificationsEnabled ? 'Выкл уведомления' : 'Вкл уведомления'}
              </button>
              <button
                onClick={() => { actions.leaveOrDeleteChat.mutate(chat.id); setMenuOpen(false) }}
                className="w-full rounded-xl px-3 py-2 text-left text-red-600 hover:bg-red-50"
              >
                {isGroup ? 'Покинуть чат' : 'Удалить чат'}
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  )
}

function ChatMessagesView({
  chat,
  currentUserId,
  focusMessageId,
  onFocusMessageHandled,
}: {
  chat: Chat
  currentUserId: string
  focusMessageId: string | null
  onFocusMessageHandled: () => void
}) {
  const messagesQuery = useChatMessagesQuery(chat.id)
  const pinnedQuery = usePinnedMessagesQuery(chat.id)
  const createMessage = useCreateMessageMutation()
  const actions = useChatActionMutations()
  const socket = useChatSocket(chat.id)
  const [content, setContent] = useState('')
  const [replyTo, setReplyTo] = useState<ChatMessage | null>(null)
  const [emojiOpen, setEmojiOpen] = useState(false)
  const [attachmentOpen, setAttachmentOpen] = useState(false)
  const [pinnedIndex, setPinnedIndex] = useState(0)
  const [highlightedMessageId, setHighlightedMessageId] = useState<string | null>(null)
  const typingStopTimeoutRef = useRef<number | null>(null)
  const messagesEndRef = useRef<HTMLDivElement | null>(null)
  const messageRefs = useRef(new Map<string, HTMLDivElement>())
  const highlightTimeoutRef = useRef<number | null>(null)
  const skipNextAutoScrollRef = useRef(false)
  const attachmentRef = useDismissibleLayer<HTMLDivElement>(attachmentOpen, () => setAttachmentOpen(false))
  const emojiRef = useDismissibleLayer<HTMLDivElement>(emojiOpen, () => setEmojiOpen(false))

  const messages = messagesQuery.data?.items ?? []
  const pinnedMessages = pinnedQuery.data?.items ?? []
  const activePinned = pinnedMessages[pinnedIndex]
  const visiblePinnedMessages = pinnedMessages.slice(0, 6)

  const setMessageRef = useCallback((messageId: string): RefCallback<HTMLDivElement> => {
    return (node) => {
      if (node) {
        messageRefs.current.set(messageId, node)
      } else {
        messageRefs.current.delete(messageId)
      }
    }
  }, [])

  const scrollToMessage = useCallback((messageId: string) => {
    const element = messageRefs.current.get(messageId)

    if (!element) {
      return
    }

    element.scrollIntoView({ behavior: 'smooth', block: 'center' })
    setHighlightedMessageId(messageId)

    if (highlightTimeoutRef.current) {
      window.clearTimeout(highlightTimeoutRef.current)
    }

    highlightTimeoutRef.current = window.setTimeout(() => {
      setHighlightedMessageId((current) => current === messageId ? null : current)
    }, 2400)
  }, [])

  function handlePinnedNavigation(nextIndex: number) {
    const normalizedIndex = Math.min(Math.max(nextIndex, 0), pinnedMessages.length - 1)
    const message = pinnedMessages[normalizedIndex]

    if (!message) {
      return
    }

    setPinnedIndex(normalizedIndex)
    scrollToMessage(message.id)
  }

  useEffect(() => {
    return () => {
      if (highlightTimeoutRef.current) {
        window.clearTimeout(highlightTimeoutRef.current)
      }
    }
  }, [])

  useEffect(() => {
    setPinnedIndex((current) => Math.min(current, Math.max(0, pinnedMessages.length - 1)))
  }, [pinnedMessages.length])

  useEffect(() => {
    if (focusMessageId) {
      return
    }

    if (skipNextAutoScrollRef.current) {
      skipNextAutoScrollRef.current = false
      return
    }

    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [focusMessageId, messages.length])

  useEffect(() => {
    if (!focusMessageId || messages.length === 0) {
      return
    }

    const frame = window.requestAnimationFrame(() => {
      scrollToMessage(focusMessageId)
      skipNextAutoScrollRef.current = true
      onFocusMessageHandled()
    })

    return () => window.cancelAnimationFrame(frame)
  }, [focusMessageId, messages.length, onFocusMessageHandled, scrollToMessage])

  useEffect(() => {
    const lastMessage = messages[messages.length - 1]
    if (lastMessage) {
      actions.markAsRead.mutate({ chatId: chat.id, messageId: lastMessage.id })
      socket.markRead(lastMessage.id)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chat.id, messages.length])

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()

    const trimmed = content.trim()

    if (!trimmed) {
      return
    }

    await createMessage.mutateAsync({ chatId: chat.id, content: trimmed, parentId: replyTo?.id })
    setContent('')
    setReplyTo(null)
    socket.sendTyping(false)
  }

  function handleTyping(value: string) {
    setContent(value)
    socket.sendTyping(true)

    if (typingStopTimeoutRef.current) {
      window.clearTimeout(typingStopTimeoutRef.current)
    }

    typingStopTimeoutRef.current = window.setTimeout(() => socket.sendTyping(false), 2000)
  }

  function handleMockAttachment(type: FileAssetType) {
    const fileNames: Record<FileAssetType, string> = {
      IMAGE: 'wine-photo.jpg',
      VIDEO: 'tasting-video.mp4',
      AUDIO: 'voice-message.mp3',
      FILE: 'tasting-notes.pdf',
      ARCHIVE: 'photos.zip',
    }

    createMessage.mutate({
      chatId: chat.id,
      content: type === 'AUDIO' ? 'Аудиосообщение' : undefined,
      attachments: [
        {
          type,
          url: `/seed/${fileNames[type]}`,
          filename: fileNames[type],
          mimeType: type === 'IMAGE' ? 'image/jpeg' : 'application/octet-stream',
        },
      ],
    })
    setAttachmentOpen(false)
  }

  return (
    <div className="flex h-full min-h-0 flex-1 flex-col">
      {activePinned && (
        <div className="shrink-0 border-b border-violet-100 bg-violet-50/60 px-6 py-3">
          <div className="flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={() => scrollToMessage(activePinned.id)}
              className="flex min-w-0 flex-1 items-center gap-2 rounded-2xl px-2 py-1 text-left transition hover:bg-white/60"
            >
              <Pin className="h-4 w-4 shrink-0 text-violet-600" />
              <span className="min-w-0">
                <span className="block text-xs font-bold text-violet-700">
                  Закрепленное сообщение {pinnedIndex + 1} из {pinnedMessages.length}
                </span>
                <span className="block truncate text-sm text-slate-700">{activePinned.content}</span>
              </span>
            </button>

            <div className="flex shrink-0 items-center gap-2">
              {pinnedMessages.length > 6 && (
                <button
                  type="button"
                  disabled={pinnedIndex === 0}
                  onClick={() => handlePinnedNavigation(pinnedIndex - 1)}
                  className="rounded-full p-1.5 text-violet-600 transition hover:bg-white disabled:cursor-not-allowed disabled:opacity-40"
                  aria-label="Предыдущее закрепленное сообщение"
                >
                  <ChevronLeft className="h-4 w-4" />
                </button>
              )}

              <div className="flex items-center gap-1">
                {visiblePinnedMessages.map((message, index) => (
                  <button
                    key={message.id}
                    type="button"
                    onClick={() => handlePinnedNavigation(index)}
                    className={`h-2.5 w-2.5 rounded-full ${index === pinnedIndex ? 'bg-violet-600' : 'bg-violet-200'}`}
                    aria-label={`Закреп ${index + 1}`}
                  />
                ))}
              </div>

              {pinnedMessages.length > 6 && (
                <button
                  type="button"
                  disabled={pinnedIndex >= pinnedMessages.length - 1}
                  onClick={() => handlePinnedNavigation(pinnedIndex + 1)}
                  className="rounded-full p-1.5 text-violet-600 transition hover:bg-white disabled:cursor-not-allowed disabled:opacity-40"
                  aria-label="Следующее закрепленное сообщение"
                >
                  <ChevronRight className="h-4 w-4" />
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      <div className="min-h-0 flex-1 overflow-y-auto overflow-x-hidden bg-gradient-to-b from-white via-violet-50/20 to-white px-6 py-6">
        <div className="mx-auto flex w-full max-w-3xl flex-col gap-5">
          {messagesQuery.isLoading && (
            <p className="py-10 text-center text-sm text-zinc-500">
              Загружаем сообщения...
            </p>
          )}

          {!messagesQuery.isLoading && messages.length === 0 && (
            <div className="flex min-h-72 flex-col items-center justify-center rounded-3xl border border-dashed border-violet-100 bg-white/70 px-6 text-center">
              <p className="text-base font-bold text-slate-900">Сообщений пока нет</p>
              <p className="mt-2 max-w-sm text-sm text-zinc-500">
                Напиши первое сообщение, и переписка появится здесь.
              </p>
            </div>
          )}

          {messages.map((message) => (
            <MessageBubble
              key={message.id}
              message={message}
              chat={chat}
              isOwn={message.senderId === currentUserId}
              currentUserId={currentUserId}
              highlighted={highlightedMessageId === message.id}
              messageRef={setMessageRef(message.id)}
              onReply={() => setReplyTo(message)}
            />
          ))}

          <div ref={messagesEndRef} />
        </div>
      </div>

      <div className="shrink-0 border-t border-zinc-100 bg-white px-6 py-4">
        {socket.typingUsers.length > 0 && (
          <p className="mb-2 text-xs font-medium text-violet-600">
            {socket.typingUsers.map((typingUser) => typingUser.username).join(', ')} печатает...
          </p>
        )}

        {replyTo && (
          <div className="mb-3 flex items-center justify-between gap-3 rounded-2xl border border-violet-100 bg-violet-50 px-4 py-3">
            <div className="min-w-0">
              <p className="text-xs font-bold text-violet-700">
                Ответ пользователю {replyTo.sender?.username ?? 'Пользователь'}
              </p>
              <p className="truncate text-sm text-slate-600">{replyTo.content}</p>
            </div>

            <button type="button" onClick={() => setReplyTo(null)} className="shrink-0 text-slate-500 hover:text-slate-900">
              <X className="h-4 w-4" />
            </button>
          </div>
        )}

        <form onSubmit={handleSubmit} className="relative flex w-full items-center gap-3 max-md:flex-wrap">
          <div ref={attachmentRef} className="relative shrink-0">
            <button type="button" onClick={() => setAttachmentOpen((value) => !value)} className="rounded-full p-2 text-slate-600 hover:bg-zinc-100">
              <Paperclip className="h-5 w-5" />
            </button>

            {attachmentOpen && (
              <div className="absolute bottom-12 left-0 z-20 grid w-56 gap-1 rounded-2xl border border-zinc-100 bg-white p-2 text-sm shadow-xl">
                <AttachmentButton icon={<ImageIcon className="h-4 w-4" />} label="Изображение" onClick={() => handleMockAttachment('IMAGE')} />
                <AttachmentButton icon={<Video className="h-4 w-4" />} label="Видео" onClick={() => handleMockAttachment('VIDEO')} />
                <AttachmentButton icon={<File className="h-4 w-4" />} label="Файл" onClick={() => handleMockAttachment('FILE')} />
                <AttachmentButton icon={<Archive className="h-4 w-4" />} label="Архив" onClick={() => handleMockAttachment('ARCHIVE')} />
              </div>
            )}
          </div>

          <input
            value={content}
            onChange={(event) => handleTyping(event.target.value)}
            placeholder="Напишите сообщение..."
            className="min-w-0 flex-1 rounded-xl border border-zinc-200 px-4 py-3 text-sm outline-none focus:border-violet-300 max-md:order-first max-md:w-full max-md:flex-none"
          />

          <div ref={emojiRef} className="relative shrink-0">
            <button type="button" onClick={() => setEmojiOpen((value) => !value)} className="rounded-full p-2 text-slate-600 hover:bg-zinc-100">
              <Smile className="h-5 w-5" />
            </button>

            {emojiOpen && (
              <div className="absolute bottom-12 right-0 z-30 grid w-60 grid-cols-5 gap-1 rounded-2xl border border-zinc-100 bg-white p-2 text-2xl leading-none shadow-xl">
                {emojiOptions.map((emoji) => (
                  <button key={emoji} type="button" onClick={() => { setContent((value) => `${value}${emoji}`); setEmojiOpen(false) }} className="flex h-10 w-10 items-center justify-center rounded-xl hover:bg-violet-50">
                    {emoji}
                  </button>
                ))}
              </div>
            )}
          </div>

          <button type="button" onClick={() => handleMockAttachment('AUDIO')} className="shrink-0 rounded-full p-2 text-slate-600 hover:bg-zinc-100">
            <Mic className="h-5 w-5" />
          </button>

          <button type="submit" className="shrink-0 rounded-full bg-violet-600 p-3 text-white shadow-lg shadow-violet-200 transition hover:bg-violet-700">
            <Send className="h-5 w-5" />
          </button>
        </form>
      </div>
    </div>
  )
}

function AttachmentButton({ icon, label, onClick }: { icon: ReactNode; label: string; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} className="flex items-center gap-2 rounded-xl px-3 py-2 text-left hover:bg-violet-50">
      {icon}
      {label}
    </button>
  )
}

function MessageBubble({
  message,
  chat,
  isOwn,
  currentUserId,
  highlighted,
  messageRef,
  onReply,
}: {
  message: ChatMessage
  chat: Chat
  isOwn: boolean
  currentUserId: string
  highlighted: boolean
  messageRef: RefCallback<HTMLDivElement>
  onReply: () => void
}) {
  const actions = useChatActionMutations()
  const [menuOpen, setMenuOpen] = useState(false)
  const menuRef = useDismissibleLayer<HTMLDivElement>(menuOpen, () => setMenuOpen(false))
  const canModerate = chat.currentUserRole === 'OWNER' || chat.currentUserRole === 'ADMIN'
  const readByOthers = message.reads.filter((read) => read.userId !== currentUserId)
  const myReaction = message.reactions.find((reaction) => reaction.userId === currentUserId)?.emoji
  const groupedReactions = useMemo(() => {
    return message.reactions.reduce<Record<string, number>>((acc, reaction) => {
      acc[reaction.emoji] = (acc[reaction.emoji] ?? 0) + 1
      return acc
    }, {})
  }, [message.reactions])

  return (
    <div ref={messageRef} className={`group flex w-full scroll-mt-28 items-end gap-3 rounded-3xl transition-shadow duration-300 ${isOwn ? 'justify-end' : 'justify-start'} ${highlighted ? 'ring-4 ring-violet-300 ring-offset-4 ring-offset-white' : ''}`}>
      {!isOwn && <Avatar title={message.sender?.username ?? 'User'} src={message.sender?.avatarUrl} size="sm" />}

      <div className={`flex max-w-xl flex-col max-md:max-w-full ${isOwn ? 'items-end' : 'items-start'}`}>
        <div className={`max-w-full rounded-3xl px-4 py-3 text-sm leading-6 shadow-sm ${isOwn ? 'bg-violet-100 text-slate-900' : 'bg-zinc-50 text-slate-900'}`}>
          {message.parent && (
            <div className="mb-2 rounded-2xl border-l-4 border-violet-400 bg-white/70 px-3 py-2 text-xs text-slate-600">
              <b>{message.parent.sender?.username ?? 'Пользователь'}</b>: {message.parent.content}
            </div>
          )}

          {message.content && <p className="whitespace-pre-wrap break-words">{message.content}</p>}

          {message.attachments.length > 0 && (
            <div className="mt-3 grid gap-2">
              {message.attachments.map((attachment) => (
                <div key={attachment.id} className="rounded-2xl border border-white/70 bg-white/70 px-3 py-2 text-xs font-semibold text-slate-700">
                  {attachment.file.type === 'IMAGE' && <ImageIcon className="mb-1 h-4 w-4 text-violet-600" />}
                  {attachment.file.type === 'VIDEO' && <Video className="mb-1 h-4 w-4 text-violet-600" />}
                  {attachment.file.type === 'AUDIO' && <Volume2 className="mb-1 h-4 w-4 text-violet-600" />}
                  {attachment.file.type === 'ARCHIVE' && <Archive className="mb-1 h-4 w-4 text-violet-600" />}
                  {attachment.file.type === 'FILE' && <File className="mb-1 h-4 w-4 text-violet-600" />}
                  {attachment.file.filename ?? attachment.file.url}
                </div>
              ))}
            </div>
          )}

          <div className="mt-2 flex items-center justify-end gap-2 text-[11px] text-zinc-500">
            <span>{formatTime(message.createdAt)}</span>
            {isOwn && <CheckCheck className={`h-4 w-4 ${readByOthers.length > 0 ? 'text-violet-600' : 'text-zinc-400'}`} />}
          </div>
        </div>

        {Object.entries(groupedReactions).length > 0 && (
          <div className={`mt-1 flex flex-wrap gap-1 ${isOwn ? 'justify-end' : 'justify-start'}`}>
            {Object.entries(groupedReactions).map(([emoji, count]) => (
              <span key={emoji} className="rounded-full border border-violet-100 bg-white px-2 py-0.5 text-xs shadow-sm">
                {emoji} {count}
              </span>
            ))}
          </div>
        )}

        {isOwn && readByOthers.length > 0 && (
          <p className="mt-1 max-w-full text-right text-[11px] text-zinc-400">
            Прочитано: {chat.type === 'GROUP' ? readByOthers.map((read) => read.user.username).join(', ') : formatTime(readByOthers[0]?.readAt)}
          </p>
        )}

        <div className={`mt-2 flex max-w-full flex-wrap gap-1 opacity-0 transition group-hover:opacity-100 ${menuOpen ? 'opacity-100' : ''} ${isOwn ? 'justify-end' : 'justify-start'}`}>
          {reactionOptions.map((emoji) => (
            <button
              key={emoji}
              onClick={() => actions.toggleReaction.mutate({ chatId: chat.id, messageId: message.id, emoji })}
              className={`rounded-full bg-white px-2 py-1 text-[11px] shadow-sm hover:bg-violet-50 ${myReaction === emoji ? 'ring-2 ring-violet-300' : ''}`}
            >
              {emoji}
            </button>
          ))}

          <button onClick={onReply} className="rounded-full bg-white px-2 py-1 text-[11px] font-semibold shadow-sm hover:bg-violet-50">
            Ответить
          </button>

          <div ref={menuRef} className="relative">
            <button onClick={() => setMenuOpen((value) => !value)} className="rounded-full bg-white px-2 py-1 text-xs shadow-sm hover:bg-violet-50">
              <MoreVertical className="h-3.5 w-3.5" />
            </button>

            {menuOpen && (
              <div className={`absolute top-8 z-10 w-48 rounded-2xl border border-zinc-100 bg-white p-2 text-xs shadow-xl ${isOwn ? 'right-0' : 'left-0'}`}>
                <button onClick={() => { actions.pinMessage.mutate({ chatId: chat.id, messageId: message.id }); setMenuOpen(false) }} className="w-full rounded-xl px-3 py-2 text-left hover:bg-violet-50">Закрепить</button>
                {message.pinnedAt && <button onClick={() => { actions.unpinMessage.mutate({ chatId: chat.id, messageId: message.id }); setMenuOpen(false) }} className="w-full rounded-xl px-3 py-2 text-left hover:bg-violet-50">Открепить</button>}
                {(isOwn || canModerate) && <button onClick={() => { actions.deleteMessage.mutate({ chatId: chat.id, messageId: message.id }); setMenuOpen(false) }} className="w-full rounded-xl px-3 py-2 text-left text-red-600 hover:bg-red-50">Удалить сообщение</button>}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

type UserPickerGroup = {
  title: string
  hint: string
  users: SocialUserCard[]
}

function useUserPickerGroups(search: string, excludedUserIds: string[] = []) {
  const friendsQuery = useFriendsQuery({ tab: 'all', search, sort: 'name', page: 1, limit: 30 })
  const followersQuery = useSubscriptionsQuery({ tab: 'followers', search, sort: 'new', page: 1, limit: 30 })
  const followingQuery = useSubscriptionsQuery({ tab: 'following', search, sort: 'new', page: 1, limit: 30 })
  const excludedKey = excludedUserIds.join('|')

  const groups = useMemo<UserPickerGroup[]>(() => {
    const excluded = new Set(excludedKey ? excludedKey.split('|') : [])
    const used = new Set(excluded)
    const friends = (friendsQuery.data?.items ?? []) as SocialUserCard[]
    const followers = ((followersQuery.data?.items ?? []) as SubscriptionItem[]).map((item) => item.user)
    const following = ((followingQuery.data?.items ?? []) as SubscriptionItem[]).map((item) => item.user)

    function takeUnique(users: SocialUserCard[]) {
      const result: SocialUserCard[] = []

      for (const user of users) {
        if (used.has(user.id)) {
          continue
        }

        used.add(user.id)
        result.push(user)
      }

      return result
    }

    return [
      {
        title: 'Друзья',
        hint: 'Люди из твоего списка друзей',
        users: takeUnique(friends),
      },
      {
        title: 'Подписчики',
        hint: 'Люди, которые подписаны на тебя',
        users: takeUnique(followers),
      },
      {
        title: 'Подписки',
        hint: 'Люди, на которых подписан(а) ты',
        users: takeUnique(following),
      },
    ]
  }, [excludedKey, followersQuery.data?.items, followingQuery.data?.items, friendsQuery.data?.items])

  return {
    groups,
    isLoading: friendsQuery.isLoading || followersQuery.isLoading || followingQuery.isLoading,
  }
}

function UserPickerList({
  groups,
  isLoading,
  selectedIds,
  onToggle,
}: {
  groups: UserPickerGroup[]
  isLoading: boolean
  selectedIds: string[]
  onToggle: (userId: string) => void
}) {
  const hasUsers = groups.some((group) => group.users.length > 0)

  if (isLoading) {
    return <p className="py-6 text-center text-sm text-zinc-500">Загружаем пользователей...</p>
  }

  if (!hasUsers) {
    return <p className="py-6 text-center text-sm text-zinc-500">Подходящие пользователи не найдены</p>
  }

  return (
    <div className="space-y-4">
      {groups.map((group) => (
        group.users.length > 0 && (
          <section key={group.title} className="space-y-2">
            <div>
              <h3 className="text-sm font-bold text-slate-900">{group.title}</h3>
              <p className="text-xs text-zinc-500">{group.hint}</p>
            </div>

            <div className="space-y-2">
              {group.users.map((candidate) => {
                const selected = selectedIds.includes(candidate.id)

                return (
                  <button
                    key={candidate.id}
                    type="button"
                    onClick={() => onToggle(candidate.id)}
                    className={`flex w-full items-center gap-3 rounded-2xl border px-3 py-3 text-left transition ${selected ? 'border-violet-300 bg-violet-50' : 'border-zinc-100 hover:bg-zinc-50'}`}
                  >
                    <Avatar title={candidate.username} src={candidate.avatarUrl} />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-bold text-slate-900">{candidate.username}</span>
                      <span className="block truncate text-xs text-zinc-500">{candidate.email}</span>
                    </span>
                    <span className={`h-5 w-5 rounded-full border ${selected ? 'border-violet-600 bg-violet-600' : 'border-zinc-300'}`} />
                  </button>
                )
              })}
            </div>
          </section>
        )
      ))}
    </div>
  )
}

function CreateGroupChatModal({ onClose, onCreated }: { onClose: () => void; onCreated: (chat: Chat) => void }) {
  const [title, setTitle] = useState('')
  const [search, setSearch] = useState('')
  const [selectedIds, setSelectedIds] = useState<string[]>([])
  const [submitError, setSubmitError] = useState<string | null>(null)
  const createGroup = useCreateGroupChatMutation()
  const modalRef = useDismissibleLayer<HTMLDivElement>(true, onClose)
  const userPicker = useUserPickerGroups(search)

  function toggleUser(userId: string) {
    setSelectedIds((value) =>
      value.includes(userId)
        ? value.filter((id) => id !== userId)
        : [...value, userId],
    )
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()

    const trimmedTitle = title.trim()
    setSubmitError(null)

    if (!trimmedTitle) {
      setSubmitError('Укажи название группового чата')
      return
    }

    if (selectedIds.length === 0) {
      setSubmitError('Выбери хотя бы одного участника')
      return
    }

    try {
      const chat = await createGroup.mutateAsync({ title: trimmedTitle, memberIds: selectedIds })
      onCreated(chat)
      onClose()
    } catch (error) {
      setSubmitError(error instanceof Error ? error.message : 'Не удалось создать групповой чат')
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/30 px-4 py-6">
      <div ref={modalRef} className="w-full max-w-lg rounded-3xl bg-white p-6 shadow-2xl">
        <div className="mb-5 flex items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-slate-950">Создать групповой чат</h2>
            <p className="mt-1 text-sm text-zinc-500">Укажи название и выбери участников из друзей, подписчиков или подписок.</p>
          </div>
          <button onClick={onClose} className="rounded-full p-2 text-slate-500 hover:bg-zinc-100">
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <label className="block">
            <span className="mb-2 block text-sm font-bold text-slate-800">Название</span>
            <input
              value={title}
              onChange={(event) => setTitle(event.target.value)}
              placeholder="Например: Wine Lovers Club"
              className="w-full rounded-2xl border border-zinc-200 px-4 py-3 text-sm outline-none focus:border-violet-300"
            />
          </label>

          <label className="flex items-center gap-2 rounded-2xl border border-zinc-200 px-3 py-2 text-sm text-zinc-400">
            <Search className="h-4 w-4" />
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Поиск друзей, подписчиков и подписок"
              className="min-w-0 flex-1 bg-transparent text-zinc-900 outline-none placeholder:text-zinc-400"
            />
          </label>

          <div className="max-h-72 overflow-y-auto pr-1">
            <UserPickerList
              groups={userPicker.groups}
              isLoading={userPicker.isLoading}
              selectedIds={selectedIds}
              onToggle={toggleUser}
            />
          </div>

          <div className="flex items-center justify-between rounded-2xl bg-violet-50 px-4 py-3 text-sm">
            <span className="font-semibold text-slate-700">Выбрано участников</span>
            <span className="font-bold text-violet-600">{selectedIds.length}</span>
          </div>

          {submitError && (
            <p className="rounded-2xl border border-red-100 bg-red-50 px-4 py-3 text-sm font-semibold text-red-600">
              {submitError}
            </p>
          )}

          <button
            type="submit"
            disabled={!title.trim() || selectedIds.length === 0 || createGroup.isPending}
            className="w-full rounded-2xl bg-violet-600 px-4 py-3 text-sm font-bold text-white shadow-lg shadow-violet-100 transition hover:bg-violet-700 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {createGroup.isPending ? 'Создаем...' : `Создать чат${selectedIds.length ? ` · ${selectedIds.length}` : ''}`}
          </button>
        </form>
      </div>
    </div>
  )
}

function InviteMembersModal({
  chat,
  excludedUserIds,
  onClose,
}: {
  chat: Chat
  excludedUserIds: string[]
  onClose: () => void
}) {
  const [search, setSearch] = useState('')
  const [selectedIds, setSelectedIds] = useState<string[]>([])
  const [submitError, setSubmitError] = useState<string | null>(null)
  const actions = useChatActionMutations()
  const modalRef = useDismissibleLayer<HTMLDivElement>(true, onClose)
  const userPicker = useUserPickerGroups(search, excludedUserIds)

  function toggleUser(userId: string) {
    setSelectedIds((value) =>
      value.includes(userId)
        ? value.filter((id) => id !== userId)
        : [...value, userId],
    )
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setSubmitError(null)

    if (selectedIds.length === 0) {
      setSubmitError('Выбери хотя бы одного участника')
      return
    }

    try {
      await actions.inviteMembers.mutateAsync({ chatId: chat.id, memberIds: selectedIds })
      onClose()
    } catch (error) {
      setSubmitError(error instanceof Error ? error.message : 'Не удалось пригласить участников')
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/30 px-4 py-6">
      <div ref={modalRef} className="w-full max-w-lg rounded-3xl bg-white p-6 shadow-2xl">
        <div className="mb-5 flex items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-slate-950">Пригласить участника</h2>
            <p className="mt-1 text-sm text-zinc-500">Можно пригласить друзей, подписчиков или пользователей из твоих подписок.</p>
          </div>
          <button onClick={onClose} className="rounded-full p-2 text-slate-500 hover:bg-zinc-100">
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <label className="flex items-center gap-2 rounded-2xl border border-zinc-200 px-3 py-2 text-sm text-zinc-400">
            <Search className="h-4 w-4" />
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Поиск друзей, подписчиков и подписок"
              className="min-w-0 flex-1 bg-transparent text-zinc-900 outline-none placeholder:text-zinc-400"
            />
          </label>

          <div className="max-h-80 overflow-y-auto pr-1">
            <UserPickerList
              groups={userPicker.groups}
              isLoading={userPicker.isLoading}
              selectedIds={selectedIds}
              onToggle={toggleUser}
            />
          </div>

          <div className="flex items-center justify-between rounded-2xl bg-violet-50 px-4 py-3 text-sm">
            <span className="font-semibold text-slate-700">Выбрано участников</span>
            <span className="font-bold text-violet-600">{selectedIds.length}</span>
          </div>

          {submitError && (
            <p className="rounded-2xl border border-red-100 bg-red-50 px-4 py-3 text-sm font-semibold text-red-600">
              {submitError}
            </p>
          )}

          <button
            type="submit"
            disabled={selectedIds.length === 0 || actions.inviteMembers.isPending}
            className="w-full rounded-2xl bg-violet-600 px-4 py-3 text-sm font-bold text-white shadow-lg shadow-violet-100 transition hover:bg-violet-700 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {actions.inviteMembers.isPending ? 'Приглашаем...' : `Пригласить${selectedIds.length ? ` · ${selectedIds.length}` : ''}`}
          </button>
        </form>
      </div>
    </div>
  )
}

function ChatMembersView({ chat }: { chat: Chat }) {
  const membersQuery = useChatMembersQuery(chat.id)
  const actions = useChatActionMutations()
  const members = membersQuery.data?.items ?? []
  const [inviteModalOpen, setInviteModalOpen] = useState(false)
  const canManage = chat.currentUserRole === 'OWNER'
  const canInvite = chat.currentUserRole === 'OWNER' || chat.currentUserRole === 'ADMIN'
  const memberUserIds = members.map((member) => member.userId)

  return (
    <>
      <div className="min-h-0 flex-1 overflow-y-auto p-6">
        <div className="mb-6 flex items-center justify-between gap-4">
          <h3 className="text-xl font-bold text-slate-950">Участники чата</h3>
          {canInvite && (
            <button
              onClick={() => setInviteModalOpen(true)}
              className="rounded-xl bg-violet-600 px-4 py-3 text-sm font-bold text-white shadow-lg shadow-violet-100 hover:bg-violet-700"
            >
              Пригласить участника
            </button>
          )}
        </div>

        <div className="space-y-3">
        {members.map((member) => (
          <div key={member.id} className="flex items-center gap-4 rounded-2xl border border-zinc-100 px-4 py-3">
            <Avatar title={member.user.username} src={member.user.avatarUrl} />
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <p className="font-bold text-slate-900">{member.user.username}</p>
                {member.role !== 'MEMBER' && <span className="rounded-full bg-violet-50 px-2 py-1 text-[11px] font-bold text-violet-600">{member.role === 'OWNER' ? 'Создатель' : 'Администратор'}</span>}
              </div>
              <p className="text-xs text-zinc-500">{isUserOnline(member.user.lastLoginAt) ? 'Онлайн' : formatLastSeen(member.user.lastLoginAt)}</p>
            </div>
            <button className="rounded-xl border border-violet-200 px-4 py-2 text-sm font-bold text-violet-600 hover:bg-violet-50">Профиль</button>
            {canManage && member.role !== 'OWNER' && (
              <div className="flex gap-2">
                <button
                  onClick={() => actions.updateMemberRole.mutate({ chatId: chat.id, userId: member.userId, role: member.role === 'ADMIN' ? 'MEMBER' : 'ADMIN' })}
                  className="rounded-xl border border-zinc-200 px-3 py-2 text-xs font-bold text-slate-600 hover:bg-zinc-50"
                >
                  {member.role === 'ADMIN' ? 'Снять админа' : 'Назначить админом'}
                </button>
                <button
                  onClick={() => actions.removeMember.mutate({ chatId: chat.id, userId: member.userId })}
                  className="rounded-xl border border-red-100 px-3 py-2 text-xs font-bold text-red-600 hover:bg-red-50"
                >
                  Удалить
                </button>
              </div>
            )}
          </div>
        ))}
        </div>
      </div>

      {inviteModalOpen && (
        <InviteMembersModal
          chat={chat}
          excludedUserIds={memberUserIds}
          onClose={() => setInviteModalOpen(false)}
        />
      )}
    </>
  )
}

function ChatAttachmentsView({
  chat,
  attachmentType,
  setAttachmentType,
}: {
  chat: Chat
  attachmentType: AttachmentTab
  setAttachmentType: (value: AttachmentTab) => void
}) {
  const attachmentsQuery = useChatAttachmentsQuery(chat.id, attachmentType === 'LINKS' ? undefined : attachmentType)
  const attachments = attachmentType === 'LINKS' ? [] : attachmentsQuery.data?.items ?? []

  return (
    <div className="min-h-0 flex-1 overflow-y-auto p-6">
      <h3 className="mb-4 text-xl font-bold text-slate-950">Вложения чата</h3>
      <label className="mb-5 flex items-center gap-2 rounded-xl border border-zinc-200 px-3 py-2 text-sm text-zinc-400">
        <Search className="h-4 w-4" />
        <input placeholder="Поиск по вложениям" className="flex-1 bg-transparent outline-none" />
      </label>

      <div className="mb-5 flex flex-wrap gap-3 border-b border-zinc-100">
        {attachmentTabs.map((tab) => (
          <button
            key={tab.value}
            onClick={() => setAttachmentType(tab.value)}
            className={`border-b-2 px-2 pb-3 text-sm font-bold ${attachmentType === tab.value ? 'border-violet-600 text-violet-600' : 'border-transparent text-slate-500 hover:text-violet-600'}`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {attachmentType === 'LINKS' ? (
        <p className="rounded-2xl bg-zinc-50 p-6 text-sm text-zinc-500">Ссылки появятся тут, когда мы добавим парсер URL из сообщений.</p>
      ) : (
        <div className="grid grid-cols-4 gap-4 max-xl:grid-cols-3 max-md:grid-cols-2">
          {attachments.map((attachment) => (
            <div key={attachment.id} className="rounded-2xl border border-zinc-100 p-3">
              <div className="mb-3 flex h-28 items-center justify-center rounded-xl bg-violet-50 text-violet-600">
                {attachment.file.type === 'IMAGE' && <ImageIcon className="h-8 w-8" />}
                {attachment.file.type === 'VIDEO' && <Video className="h-8 w-8" />}
                {attachment.file.type === 'AUDIO' && <Volume2 className="h-8 w-8" />}
                {attachment.file.type === 'ARCHIVE' && <Archive className="h-8 w-8" />}
                {attachment.file.type === 'FILE' && <File className="h-8 w-8" />}
              </div>
              <p className="truncate text-sm font-bold text-slate-800">{attachment.file.filename}</p>
              <p className="mt-1 text-xs text-zinc-500">{formatTime(attachment.createdAt)}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
