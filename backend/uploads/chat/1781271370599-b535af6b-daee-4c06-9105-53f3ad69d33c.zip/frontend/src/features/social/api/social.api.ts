import type {
  CreatePostPayload,
  FeedPost,
  FriendsResponse,
  FriendsSort,
  FriendsTab,
  PostCommentsResponse,
  PostsResponse,
  PublicProfileResponse,
  ReactionType,
  SubscriptionsResponse,
  SubscriptionsSort,
  SubscriptionsTab,
} from '../types/social.types'

const API_URL = process.env.NEXT_PUBLIC_API_URL

type ApiErrorBody = {
  message?: string | string[]
  error?: string
}

async function apiRequest<T>(
  path: string,
  accessToken: string,
  options: RequestInit = {},
): Promise<T> {
  const response = await fetch(`${API_URL}${path}`, {
    ...options,
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`,
      ...options.headers,
    },
  })

  if (!response.ok) {
    let errorMessage = 'Request failed'

    try {
      const errorBody = (await response.json()) as ApiErrorBody

      if (Array.isArray(errorBody.message)) {
        errorMessage = errorBody.message.join(', ')
      } else if (errorBody.message) {
        errorMessage = errorBody.message
      } else if (errorBody.error) {
        errorMessage = errorBody.error
      }
    } catch {
      errorMessage = response.statusText
    }

    throw new Error(errorMessage)
  }

  return response.json() as Promise<T>
}

function buildQuery(params: Record<string, string | number | undefined>) {
  const query = new URLSearchParams()

  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== '') {
      query.set(key, String(value))
    }
  }

  return query.toString()
}

export const socialApi = {
  getFriends(
    accessToken: string,
    params: {
      tab: FriendsTab
      search?: string
      sort?: FriendsSort
      page?: number
      limit?: number
    },
  ) {
    return apiRequest<FriendsResponse>(
      `/users/friends?${buildQuery(params)}`,
      accessToken,
    )
  },

  getSubscriptions(
    accessToken: string,
    params: {
      tab: SubscriptionsTab
      search?: string
      sort?: SubscriptionsSort
      page?: number
      limit?: number
    },
  ) {
    return apiRequest<SubscriptionsResponse>(
      `/users/subscriptions?${buildQuery(params)}`,
      accessToken,
    )
  },

  getPublicProfile(accessToken: string, userId: string) {
    return apiRequest<PublicProfileResponse>(
      `/profiles/${userId}`,
      accessToken,
    )
  },

  createPost(accessToken: string, payload: CreatePostPayload) {
    return apiRequest<FeedPost>('/posts', accessToken, {
      method: 'POST',
      body: JSON.stringify(payload),
    })
  },

  getUserPosts(
    accessToken: string,
    userId: string,
    params: {
      page?: number
      limit?: number
    },
  ) {
    return apiRequest<PostsResponse>(
      `/posts/users/${userId}?${buildQuery(params)}`,
      accessToken,
    )
  },

  getFeedPosts(
    accessToken: string,
    params: {
      page?: number
      limit?: number
    },
  ) {
    return apiRequest<PostsResponse>(
      `/posts/feed?${buildQuery(params)}`,
      accessToken,
    )
  },

  togglePostReaction(
    accessToken: string,
    postId: string,
    type: ReactionType,
  ) {
    return apiRequest<FeedPost>(
      `/posts/${postId}/reactions/toggle`,
      accessToken,
      {
        method: 'POST',
        body: JSON.stringify({ type }),
      },
    )
  },

  getPostComments(accessToken: string, postId: string) {
    return apiRequest<PostCommentsResponse>(
      `/posts/${postId}/comments`,
      accessToken,
    )
  },

  createPostComment(
    accessToken: string,
    postId: string,
    payload: {
      content: string
      parentId?: string | null
    },
  ) {
    return apiRequest<PostCommentsResponse>(
      `/posts/${postId}/comments`,
      accessToken,
      {
        method: 'POST',
        body: JSON.stringify(payload),
      },
    )
  },

  toggleCommentReaction(
    accessToken: string,
    commentId: string,
    type: ReactionType,
  ) {
    return apiRequest<PostCommentsResponse>(
      `/posts/comments/${commentId}/reactions/toggle`,
      accessToken,
      {
        method: 'POST',
        body: JSON.stringify({ type }),
      },
    )
  },

  sendFriendRequest(accessToken: string, targetUserId: string) {
    return apiRequest<{ success: true }>(
      `/users/${targetUserId}/friend-request`,
      accessToken,
      {
        method: 'POST',
      },
    )
  },

  acceptFriendRequest(accessToken: string, requestId: string) {
    return apiRequest<{ success: true }>(
      `/users/friend-requests/${requestId}/accept`,
      accessToken,
      {
        method: 'POST',
      },
    )
  },

  declineFriendRequest(accessToken: string, requestId: string) {
    return apiRequest<{ success: true }>(
      `/users/friend-requests/${requestId}/decline`,
      accessToken,
      {
        method: 'POST',
      },
    )
  },

  removeFriend(accessToken: string, friendId: string) {
    return apiRequest<{ success: true }>(
      `/users/friends/${friendId}`,
      accessToken,
      {
        method: 'DELETE',
      },
    )
  },

  unfollowUser(accessToken: string, targetUserId: string) {
    return apiRequest<{ success: true }>(
      `/users/following/${targetUserId}`,
      accessToken,
      {
        method: 'DELETE',
      },
    )
  },

  removeFollower(accessToken: string, followerId: string) {
    return apiRequest<{ success: true }>(
      `/users/followers/${followerId}`,
      accessToken,
      {
        method: 'DELETE',
      },
    )
  },
}