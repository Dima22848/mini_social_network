'use client'

import { useMemo, useState } from 'react'
import Link from 'next/link'
import {
  Archive,
  FileText,
  Heart,
  Loader2,
  MessageCircle,
  Music,
  Send,
  ThumbsDown,
} from 'lucide-react'
import {
  useCreatePostCommentMutation,
  usePostCommentsQuery,
  useToggleCommentReactionMutation,
  useTogglePostReactionMutation,
} from '@/features/social/api/social.queries'
import { useAuth } from '@/features/auth/providers/AuthProvider'
import type {
  FeedPost,
  FeedPostAttachment,
  PostComment,
  ReactionType,
} from '@/features/social/types/social.types'

type PostCardProps = {
  post: FeedPost
}

function formatDate(date: string) {
  return new Intl.DateTimeFormat('ru-RU', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(date))
}

function formatFileSize(sizeBytes: number | null) {
  if (!sizeBytes) {
    return 'Размер неизвестен'
  }

  if (sizeBytes < 1024 * 1024) {
    return `${Math.round(sizeBytes / 1024)} KB`
  }

  return `${(sizeBytes / 1024 / 1024).toFixed(1)} MB`
}

function buildCommentsTree(comments: PostComment[]) {
  const map = new Map<string, PostComment & { replies: PostComment[] }>()
  const roots: Array<PostComment & { replies: PostComment[] }> = []

  for (const comment of comments) {
    map.set(comment.id, {
      ...comment,
      replies: [],
    })
  }

  for (const comment of map.values()) {
    if (comment.parentId && map.has(comment.parentId)) {
      map.get(comment.parentId)!.replies.push(comment)
    } else {
      roots.push(comment)
    }
  }

  return roots
}

export function PostCard({ post }: PostCardProps) {
  const { user } = useAuth()
  const currentPost = post
  const [areCommentsOpen, setAreCommentsOpen] = useState(false)
  const [commentText, setCommentText] = useState('')
  const [replyTexts, setReplyTexts] = useState<Record<string, string>>({})
  const [replyingToId, setReplyingToId] = useState<string | null>(null)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)

  const commentsQuery = usePostCommentsQuery(currentPost.id, areCommentsOpen)
  const togglePostReactionMutation = useTogglePostReactionMutation()
  const createCommentMutation = useCreatePostCommentMutation()
  const toggleCommentReactionMutation = useToggleCommentReactionMutation()

  const commentsTree = useMemo(
    () => buildCommentsTree(commentsQuery.data?.items ?? []),
    [commentsQuery.data],
  )

  const pendingAction = togglePostReactionMutation.isPending
    ? `post-reaction-${togglePostReactionMutation.variables?.type}`
    : createCommentMutation.isPending
      ? createCommentMutation.variables?.parentId
        ? `reply-${createCommentMutation.variables.parentId}`
        : 'root-comment'
      : toggleCommentReactionMutation.isPending
        ? `comment-${toggleCommentReactionMutation.variables?.commentId}-${toggleCommentReactionMutation.variables?.type}`
        : null

  async function toggleComments() {
    setAreCommentsOpen((prev) => !prev)
  }

  async function togglePostReaction(type: ReactionType) {
    try {
      setErrorMessage(null)
      await togglePostReactionMutation.mutateAsync({
        postId: currentPost.id,
        type,
      })
    } catch (error) {
      setErrorMessage(
        error instanceof Error ? error.message : 'Не удалось поставить реакцию',
      )
    }
  }

  async function createComment(parentId?: string | null) {
    const content = parentId ? replyTexts[parentId]?.trim() : commentText.trim()

    if (!content) {
      return
    }

    try {
      setErrorMessage(null)
      await createCommentMutation.mutateAsync({
        postId: currentPost.id,
        content,
        parentId: parentId ?? null,
      })
      setAreCommentsOpen(true)

      if (parentId) {
        setReplyTexts((prev) => ({
          ...prev,
          [parentId]: '',
        }))
        setReplyingToId(null)
      } else {
        setCommentText('')
      }

    } catch (error) {
      setErrorMessage(
        error instanceof Error
          ? error.message
          : 'Не удалось отправить комментарий',
      )
    }
  }

  async function toggleCommentReaction(commentId: string, type: ReactionType) {
    try {
      setErrorMessage(null)
      await toggleCommentReactionMutation.mutateAsync({ commentId, type })
    } catch (error) {
      setErrorMessage(
        error instanceof Error
          ? error.message
          : 'Не удалось поставить реакцию на комментарий',
      )
    }
  }

  return (
    <article className="rounded-3xl border border-zinc-100 bg-white p-6 shadow-sm max-md:p-4">
      <div className="flex items-start gap-4">
        <Link
          href={`/profile/${currentPost.author.id}`}
          className="flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-full bg-violet-100 text-lg font-bold text-violet-700"
        >
          {currentPost.author.avatarUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={currentPost.author.avatarUrl}
              alt={currentPost.author.username}
              className="h-full w-full object-cover"
            />
          ) : (
            currentPost.author.username.slice(0, 1).toUpperCase()
          )}
        </Link>

        <div className="min-w-0">
          <Link
            href={`/profile/${currentPost.author.id}`}
            className="font-bold text-zinc-950 transition hover:text-violet-700"
          >
            {currentPost.author.username}
          </Link>

          <p className="mt-0.5 text-sm font-medium text-zinc-400">
            {formatDate(currentPost.createdAt)}
          </p>
        </div>
      </div>

      {currentPost.content && (
        <p className="mt-5 whitespace-pre-wrap text-sm leading-7 text-zinc-700">
          {currentPost.content}
        </p>
      )}

      {currentPost.attachments.length > 0 && (
        <div className="mt-5 grid gap-3">
          {currentPost.attachments.map((attachment) => (
            <AttachmentPreview key={attachment.id} attachment={attachment} />
          ))}
        </div>
      )}

      <div className="mt-5 flex flex-wrap items-center gap-3 border-t border-zinc-100 pt-4">
        <button
          type="button"
          disabled={pendingAction === 'post-reaction-LIKE'}
          onClick={() => togglePostReaction('LIKE')}
          className={
            currentPost.viewerReaction === 'LIKE'
              ? 'inline-flex items-center gap-2 rounded-2xl border border-violet-200 bg-violet-50 px-4 py-2.5 text-sm font-bold text-violet-700 transition disabled:opacity-60'
              : 'inline-flex items-center gap-2 rounded-2xl border border-zinc-100 bg-white px-4 py-2.5 text-sm font-bold text-zinc-500 transition hover:border-violet-200 hover:text-violet-700 disabled:opacity-60'
          }
        >
          {pendingAction === 'post-reaction-LIKE' ? (
            <Loader2 className="animate-spin" size={17} />
          ) : (
            <Heart size={17} />
          )}
          {currentPost.likesCount}
        </button>

        <button
          type="button"
          disabled={pendingAction === 'post-reaction-DISLIKE'}
          onClick={() => togglePostReaction('DISLIKE')}
          className={
            currentPost.viewerReaction === 'DISLIKE'
              ? 'inline-flex items-center gap-2 rounded-2xl border border-red-200 bg-red-50 px-4 py-2.5 text-sm font-bold text-red-500 transition disabled:opacity-60'
              : 'inline-flex items-center gap-2 rounded-2xl border border-zinc-100 bg-white px-4 py-2.5 text-sm font-bold text-zinc-500 transition hover:border-red-200 hover:text-red-500 disabled:opacity-60'
          }
        >
          {pendingAction === 'post-reaction-DISLIKE' ? (
            <Loader2 className="animate-spin" size={17} />
          ) : (
            <ThumbsDown size={17} />
          )}
          {currentPost.dislikesCount}
        </button>

        <button
          type="button"
          onClick={toggleComments}
          className="inline-flex items-center gap-2 rounded-2xl border border-zinc-100 bg-white px-4 py-2.5 text-sm font-bold text-zinc-500 transition hover:border-violet-200 hover:text-violet-700"
        >
          <MessageCircle size={17} />
          {currentPost.commentsCount}
        </button>
      </div>

      {errorMessage && (
        <div className="mt-4 rounded-2xl border border-red-100 bg-red-50 px-4 py-3 text-sm font-semibold text-red-600">
          {errorMessage}
        </div>
      )}

      {areCommentsOpen && (
        <div className="mt-5 border-t border-zinc-100 pt-5">
          <div className="flex gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-full bg-violet-100 text-sm font-bold text-violet-700">
              {user?.username?.slice(0, 1).toUpperCase() ?? 'U'}
            </div>

            <div className="flex-1">
              <textarea
                value={commentText}
                onChange={(event) => setCommentText(event.target.value)}
                placeholder="Написать комментарий..."
                className="min-h-20 w-full resize-none rounded-2xl border border-zinc-100 bg-zinc-50 px-4 py-3 text-sm font-medium text-zinc-800 outline-none transition placeholder:text-zinc-400 focus:border-violet-200 focus:bg-white"
              />

              <div className="mt-2 flex justify-end">
                <button
                  type="button"
                  disabled={pendingAction === 'root-comment' || !commentText.trim()}
                  onClick={() => createComment(null)}
                  className="inline-flex items-center gap-2 rounded-2xl bg-violet-600 px-4 py-2.5 text-sm font-bold text-white shadow-lg shadow-violet-200 transition hover:bg-violet-700 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {pendingAction === 'root-comment' ? (
                    <Loader2 className="animate-spin" size={17} />
                  ) : (
                    <Send size={17} />
                  )}
                  Отправить
                </button>
              </div>
            </div>
          </div>

          {commentsQuery.isLoading ? (
            <div className="flex min-h-24 items-center justify-center">
              <Loader2 className="animate-spin text-violet-600" size={24} />
            </div>
          ) : commentsTree.length > 0 ? (
            <div className="mt-5 space-y-4">
              {commentsTree.map((comment) => (
                <CommentItem
                  key={comment.id}
                  comment={comment}
                  level={0}
                  pendingAction={pendingAction}
                  replyingToId={replyingToId}
                  replyText={replyTexts[comment.id] ?? ''}
                  onStartReply={() => setReplyingToId(comment.id)}
                  onCancelReply={() => setReplyingToId(null)}
                  onReplyTextChange={(value) =>
                    setReplyTexts((prev) => ({
                      ...prev,
                      [comment.id]: value,
                    }))
                  }
                  onCreateReply={() => createComment(comment.id)}
                  onToggleReaction={toggleCommentReaction}
                />
              ))}
            </div>
          ) : (
            <p className="mt-5 rounded-2xl bg-zinc-50 px-4 py-4 text-center text-sm font-medium text-zinc-500">
              Комментариев пока нет. Будьте первым.
            </p>
          )}
        </div>
      )}
    </article>
  )
}
function CommentItem({
  comment,
  level,
  pendingAction,
  replyingToId,
  replyText,
  onStartReply,
  onCancelReply,
  onReplyTextChange,
  onCreateReply,
  onToggleReaction,
}: {
  comment: PostComment & { replies?: PostComment[] }
  level: number
  pendingAction: string | null
  replyingToId: string | null
  replyText: string
  onStartReply: () => void
  onCancelReply: () => void
  onReplyTextChange: (value: string) => void
  onCreateReply: () => void
  onToggleReaction: (commentId: string, type: ReactionType) => void
}) {
  const replies = comment.replies ?? []
  const isReplyOpen = replyingToId === comment.id

  return (
    <div className={level > 0 ? 'ml-8 border-l border-zinc-100 pl-4' : ''}>
      <div className="flex gap-3">
        <Link
          href={`/profile/${comment.author.id}`}
          className="flex h-9 w-9 shrink-0 items-center justify-center overflow-hidden rounded-full bg-violet-100 text-sm font-bold text-violet-700"
        >
          {comment.author.avatarUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={comment.author.avatarUrl}
              alt={comment.author.username}
              className="h-full w-full object-cover"
            />
          ) : (
            comment.author.username.slice(0, 1).toUpperCase()
          )}
        </Link>

        <div className="min-w-0 flex-1">
          <div className="rounded-2xl bg-zinc-50 px-4 py-3">
            <Link
              href={`/profile/${comment.author.id}`}
              className="text-sm font-bold text-zinc-950 hover:text-violet-700"
            >
              {comment.author.username}
            </Link>

            <p className="mt-1 whitespace-pre-wrap text-sm leading-6 text-zinc-700">
              {comment.content}
            </p>
          </div>

          <div className="mt-2 flex flex-wrap items-center gap-2">
            <button
              type="button"
              disabled={pendingAction === `comment-${comment.id}-LIKE`}
              onClick={() => onToggleReaction(comment.id, 'LIKE')}
              className={
                comment.viewerReaction === 'LIKE'
                  ? 'inline-flex items-center gap-1 rounded-xl bg-violet-50 px-3 py-1.5 text-xs font-bold text-violet-700 disabled:opacity-60'
                  : 'inline-flex items-center gap-1 rounded-xl px-3 py-1.5 text-xs font-bold text-zinc-500 hover:bg-violet-50 hover:text-violet-700 disabled:opacity-60'
              }
            >
              <Heart size={14} />
              {comment.likesCount}
            </button>

            <button
              type="button"
              disabled={pendingAction === `comment-${comment.id}-DISLIKE`}
              onClick={() => onToggleReaction(comment.id, 'DISLIKE')}
              className={
                comment.viewerReaction === 'DISLIKE'
                  ? 'inline-flex items-center gap-1 rounded-xl bg-red-50 px-3 py-1.5 text-xs font-bold text-red-500 disabled:opacity-60'
                  : 'inline-flex items-center gap-1 rounded-xl px-3 py-1.5 text-xs font-bold text-zinc-500 hover:bg-red-50 hover:text-red-500 disabled:opacity-60'
              }
            >
              <ThumbsDown size={14} />
              {comment.dislikesCount}
            </button>

            <button
              type="button"
              onClick={onStartReply}
              className="rounded-xl px-3 py-1.5 text-xs font-bold text-zinc-500 transition hover:bg-violet-50 hover:text-violet-700"
            >
              Ответить
            </button>

            <span className="text-xs font-medium text-zinc-400">
              {formatDate(comment.createdAt)}
            </span>
          </div>

          {isReplyOpen && (
            <div className="mt-3">
              <textarea
                value={replyText}
                onChange={(event) => onReplyTextChange(event.target.value)}
                placeholder={`Ответить ${comment.author.username}...`}
                className="min-h-16 w-full resize-none rounded-2xl border border-zinc-100 bg-white px-4 py-3 text-sm font-medium text-zinc-800 outline-none transition placeholder:text-zinc-400 focus:border-violet-200"
              />

              <div className="mt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={onCancelReply}
                  className="rounded-2xl border border-zinc-100 bg-white px-4 py-2 text-sm font-bold text-zinc-500 transition hover:bg-zinc-50"
                >
                  Отмена
                </button>

                <button
                  type="button"
                  disabled={pendingAction === `reply-${comment.id}` || !replyText.trim()}
                  onClick={onCreateReply}
                  className="inline-flex items-center gap-2 rounded-2xl bg-violet-600 px-4 py-2 text-sm font-bold text-white shadow-lg shadow-violet-200 transition hover:bg-violet-700 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {pendingAction === `reply-${comment.id}` ? (
                    <Loader2 className="animate-spin" size={16} />
                  ) : (
                    <Send size={16} />
                  )}
                  Ответить
                </button>
              </div>
            </div>
          )}

          {replies.length > 0 && (
            <div className="mt-4 space-y-4">
              {replies.map((reply) => (
                <CommentItem
                  key={reply.id}
                  comment={reply}
                  level={level + 1}
                  pendingAction={pendingAction}
                  replyingToId={replyingToId}
                  replyText=""
                  onStartReply={() => {}}
                  onCancelReply={() => {}}
                  onReplyTextChange={() => {}}
                  onCreateReply={() => {}}
                  onToggleReaction={onToggleReaction}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

function AttachmentPreview({ attachment }: { attachment: FeedPostAttachment }) {
  const file = attachment.file

  if (file.type === 'IMAGE') {
    return (
      <a
        href={file.url}
        target="_blank"
        className="block overflow-hidden rounded-3xl border border-zinc-100 bg-zinc-50"
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={file.url}
          alt={file.filename ?? 'image'}
          className="max-h-[420px] w-full object-cover"
        />
      </a>
    )
  }

  if (file.type === 'VIDEO') {
    return (
      <div className="overflow-hidden rounded-3xl border border-zinc-100 bg-black">
        <video
          src={file.url}
          poster={file.thumbnailUrl ?? undefined}
          controls
          className="max-h-[420px] w-full"
        />
      </div>
    )
  }

  if (file.type === 'AUDIO') {
    return (
      <div className="rounded-3xl border border-zinc-100 bg-violet-50 p-4">
        <div className="mb-3 flex items-center gap-3 text-sm font-bold text-violet-700">
          <Music size={18} />
          {file.filename ?? 'Аудиофайл'}
        </div>

        <audio src={file.url} controls className="w-full" />
      </div>
    )
  }

  const Icon = file.type === 'ARCHIVE' ? Archive : FileText

  return (
    <a
      href={file.url}
      target="_blank"
      className="flex items-center gap-4 rounded-3xl border border-zinc-100 bg-white p-4 transition hover:border-violet-200 hover:bg-violet-50"
    >
      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-violet-100 text-violet-700">
        <Icon size={22} />
      </div>

      <div className="min-w-0">
        <p className="truncate text-sm font-bold text-zinc-900">
          {file.filename ?? 'Файл'}
        </p>

        <p className="mt-1 text-sm font-medium text-zinc-400">
          {formatFileSize(file.sizeBytes)}
        </p>
      </div>
    </a>
  )
}