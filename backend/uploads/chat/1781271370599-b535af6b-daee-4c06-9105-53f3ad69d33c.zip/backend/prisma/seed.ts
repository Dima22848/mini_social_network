import 'dotenv/config'
import {
  ChatMemberRole,
  ChatType,
  FileAssetStatus,
  FileAssetType,
  FollowSource,
  FriendRequestStatus,
  PrismaClient,
} from '@prisma/client'
import { PrismaPg } from '@prisma/adapter-pg'
import * as bcrypt from 'bcrypt'

const adapter = new PrismaPg({
  connectionString: process.env.DATABASE_URL,
})

const prisma = new PrismaClient({
  adapter,
})

const defaultPassword = '12345678'

type SeedUserInput = {
  email: string
  username: string
  bio: string
  age: number
  city: string
  country: string
  avatarUrl?: string
}

type SeedFileInput = {
  type: FileAssetType
  url: string
  thumbnailUrl?: string
  filename: string
  mimeType: string
  sizeBytes: number
  width?: number
  height?: number
  duration?: number
}

function getFriendshipPair(firstUserId: string, secondUserId: string) {
  return [firstUserId, secondUserId].sort() as [string, string]
}

async function clearDatabase() {
  console.log('Clearing database...')

  await prisma.notificationPreference.deleteMany()
  await prisma.notification.deleteMany()
  await prisma.emailOutbox.deleteMany()

  await prisma.messageRead.deleteMany()
  await prisma.messageReaction.deleteMany()
  await prisma.messageAttachment.deleteMany()
  await prisma.message.deleteMany()
  await prisma.chatInvite.deleteMany()
  await prisma.chatMember.deleteMany()
  await prisma.chat.deleteMany()

  await prisma.postCommentReaction.deleteMany()
  await prisma.postReaction.deleteMany()
  await prisma.postComment.deleteMany()
  await prisma.postAttachment.deleteMany()
  await prisma.post.deleteMany()

  await prisma.fileAsset.deleteMany()

  await prisma.friendRequest.deleteMany()
  await prisma.follow.deleteMany()
  await prisma.friendship.deleteMany()

  await prisma.session.deleteMany()
  await prisma.oAuthAccount.deleteMany()
  await prisma.userProfile.deleteMany()
  await prisma.user.deleteMany()

  console.log('Database cleared.')
}

async function createUser(data: SeedUserInput) {
  const passwordHash = await bcrypt.hash(defaultPassword, 10)

  return prisma.user.create({
    data: {
      email: data.email,
      username: data.username,
      passwordHash,
      isEmailVerified: true,
      profile: {
        create: {
          bio: data.bio,
          age: data.age,
          city: data.city,
          country: data.country,
          avatarUrl: data.avatarUrl ?? null,
        },
      },
    },
    include: {
      profile: true,
    },
  })
}

async function createFriendship(firstUserId: string, secondUserId: string) {
  const [userAId, userBId] = getFriendshipPair(firstUserId, secondUserId)

  return prisma.friendship.create({
    data: {
      userAId,
      userBId,
    },
  })
}

async function createFollow(followerId: string, followingId: string) {
  if (followerId === followingId) {
    return
  }

  return prisma.follow.create({
    data: {
      followerId,
      followingId,
      source: FollowSource.FRIEND_REQUEST_IGNORING,
    },
  })
}

async function createFriendRequest(fromUserId: string, toUserId: string) {
  if (fromUserId === toUserId) {
    return
  }

  return prisma.friendRequest.create({
    data: {
      fromUserId,
      toUserId,
      status: FriendRequestStatus.PENDING,
    },
  })
}

async function createFileAsset(uploadedById: string, data: SeedFileInput) {
  return prisma.fileAsset.create({
    data: {
      uploadedById,
      type: data.type,
      status: FileAssetStatus.READY,
      url: data.url,
      thumbnailUrl: data.thumbnailUrl ?? null,
      filename: data.filename,
      mimeType: data.mimeType,
      sizeBytes: data.sizeBytes,
      width: data.width ?? null,
      height: data.height ?? null,
      duration: data.duration ?? null,
    },
  })
}

async function createPostWithAttachments(data: {
  authorId: string
  content: string
  files: SeedFileInput[]
}) {
  const post = await prisma.post.create({
    data: {
      authorId: data.authorId,
      content: data.content,
    },
  })

  for (const [index, fileData] of data.files.entries()) {
    const file = await createFileAsset(data.authorId, fileData)

    await prisma.postAttachment.create({
      data: {
        postId: post.id,
        fileId: file.id,
        sortOrder: index,
      },
    })
  }

  return post
}


async function createDirectChatWithMessages(data: {
  firstUserId: string
  secondUserId: string
  messages: { senderId: string; content: string; minutesAgo: number; parentIndex?: number; pinned?: boolean }[]
}) {
  const directKey = [data.firstUserId, data.secondUserId].sort().join(':')

  const chat = await prisma.chat.create({
    data: {
      type: ChatType.DIRECT,
      directKey,
      createdById: data.firstUserId,
      members: {
        create: [
          { userId: data.firstUserId, role: ChatMemberRole.OWNER, lastReadAt: new Date() },
          { userId: data.secondUserId, role: ChatMemberRole.MEMBER, lastReadAt: new Date() },
        ],
      },
    },
  })

  const createdMessages: { id: string; createdAt: Date }[] = []

  for (const message of data.messages) {
    const createdAt = new Date(Date.now() - message.minutesAgo * 60 * 1000)
    const created = await prisma.message.create({
      data: {
        chatId: chat.id,
        senderId: message.senderId,
        content: message.content,
        parentId: message.parentIndex !== undefined ? createdMessages[message.parentIndex]?.id : undefined,
        pinnedAt: message.pinned ? createdAt : null,
        pinnedById: message.pinned ? data.firstUserId : null,
        createdAt,
        updatedAt: createdAt,
      },
    })

    await prisma.messageRead.createMany({
      data: [
        { messageId: created.id, userId: data.firstUserId, readAt: new Date() },
        { messageId: created.id, userId: data.secondUserId, readAt: new Date() },
      ],
      skipDuplicates: true,
    })

    createdMessages.push({ id: created.id, createdAt })
  }

  const last = createdMessages[createdMessages.length - 1]
  await prisma.chat.update({
    where: { id: chat.id },
    data: { lastMessageId: last?.id, lastMessageAt: last?.createdAt },
  })

  return chat
}

async function createGroupChatWithMessages(data: {
  title: string
  ownerId: string
  adminIds: string[]
  memberIds: string[]
  messages: { senderId: string; content: string; minutesAgo: number; pinned?: boolean; file?: SeedFileInput }[]
}) {
  const allMemberIds = [...new Set([data.ownerId, ...data.adminIds, ...data.memberIds])]

  const chat = await prisma.chat.create({
    data: {
      type: ChatType.GROUP,
      title: data.title,
      createdById: data.ownerId,
      members: {
        create: allMemberIds.map((userId) => ({
          userId,
          role: userId === data.ownerId ? ChatMemberRole.OWNER : data.adminIds.includes(userId) ? ChatMemberRole.ADMIN : ChatMemberRole.MEMBER,
          lastReadAt: new Date(),
        })),
      },
    },
  })

  const createdMessages: { id: string; createdAt: Date }[] = []

  for (const message of data.messages) {
    const createdAt = new Date(Date.now() - message.minutesAgo * 60 * 1000)
    const created = await prisma.message.create({
      data: {
        chatId: chat.id,
        senderId: message.senderId,
        content: message.content,
        type: message.file ? 'TEXT_WITH_MEDIA' : 'TEXT',
        pinnedAt: message.pinned ? createdAt : null,
        pinnedById: message.pinned ? data.ownerId : null,
        createdAt,
        updatedAt: createdAt,
      },
    })

    if (message.file) {
      const file = await createFileAsset(message.senderId, message.file)
      await prisma.messageAttachment.create({
        data: { messageId: created.id, fileId: file.id },
      })
    }

    await prisma.messageRead.createMany({
      data: allMemberIds.map((userId) => ({ messageId: created.id, userId, readAt: new Date() })),
      skipDuplicates: true,
    })

    createdMessages.push({ id: created.id, createdAt })
  }

  const last = createdMessages[createdMessages.length - 1]
  await prisma.chat.update({
    where: { id: chat.id },
    data: { lastMessageId: last?.id, lastMessageAt: last?.createdAt },
  })

  return chat
}

async function main() {
  console.log('Start seed...')

  await clearDatabase()

  const dima = await createUser({
    email: '4918bolia@ogasa.org.ua',
    username: 'dima',
    bio: 'Люблю fullstack-разработку, аккуратные интерфейсы, NestJS, Next.js и нормальную архитектуру.',
    age: 24,
    city: 'Odesa',
    country: 'Ukraine',
  })

  const olga = await createUser({
    email: 'olga.tasting@example.com',
    username: 'olga_tasting',
    bio: 'Люблю бургундию, итальянскую кухню и уютные дегустации.',
    age: 27,
    city: 'Kyiv',
    country: 'Ukraine',
  })

  const andrey = await createUser({
    email: 'somov.andrey@example.com',
    username: 'somov_andrey',
    bio: 'Коллекционирую виски и ромы. Иногда пишу короткие обзоры.',
    age: 31,
    city: 'Lviv',
    country: 'Ukraine',
  })

  const kate = await createUser({
    email: 'kate.lavie@example.com',
    username: 'kate_lavie',
    bio: 'Путешествую и дегустирую по всему миру. Люблю винные маршруты.',
    age: 29,
    city: 'Paris',
    country: 'France',
  })

  const sergey = await createUser({
    email: 'sergey.taste@example.com',
    username: 'sergey_taste',
    bio: 'Люблю крепкий алкоголь, сигары и редкие релизы.',
    age: 34,
    city: 'Warsaw',
    country: 'Poland',
  })

  const maria = await createUser({
    email: 'maria.vino@example.com',
    username: 'maria_vino',
    bio: 'Винный эксперт и автор небольшого винного блога.',
    age: 30,
    city: 'Rome',
    country: 'Italy',
  })

  const nikolay = await createUser({
    email: 'nikolay.taste@example.com',
    username: 'nikolay_taste',
    bio: 'Пишу короткие заметки о дегустациях и новых бутылках.',
    age: 26,
    city: 'Odesa',
    country: 'Ukraine',
  })

  const anna = await createUser({
    email: 'anna.wine@example.com',
    username: 'anna_wine',
    bio: 'Шампанское, сыр и хорошие разговоры — мой идеальный вечер.',
    age: 28,
    city: 'Prague',
    country: 'Czech Republic',
  })

  const victor = await createUser({
    email: 'victor.whisky@example.com',
    username: 'victor_whisky',
    bio: 'Фанат островного виски и торфяных ароматов.',
    age: 33,
    city: 'Berlin',
    country: 'Germany',
  })

  const julia = await createUser({
    email: 'julia.tasting@example.com',
    username: 'julia_tasting',
    bio: 'Люблю гастрономические пары и красивые винные истории.',
    age: 25,
    city: 'Barcelona',
    country: 'Spain',
  })

  const pavel = await createUser({
    email: 'pavel.cocktails@example.com',
    username: 'pavel_cocktails',
    bio: 'Коктейли, bitters, лёд и баланс вкуса.',
    age: 32,
    city: 'Odesa',
    country: 'Ukraine',
  })

  // Друзья dima
  await createFriendship(dima.id, olga.id)
  await createFriendship(dima.id, andrey.id)
  await createFriendship(dima.id, kate.id)

  // Дополнительные связи между другими пользователями, чтобы были общие друзья
  await createFriendship(olga.id, andrey.id)
  await createFriendship(olga.id, maria.id)
  await createFriendship(kate.id, julia.id)

  // Только подписчики dima
  await createFollow(maria.id, dima.id)
  await createFollow(sergey.id, dima.id)
  await createFollow(julia.id, dima.id)
  await createFollow(pavel.id, dima.id)

  // Только подписки dima
  await createFollow(dima.id, nikolay.id)
  await createFollow(dima.id, anna.id)
  await createFollow(dima.id, victor.id)

  // Заявки в друзья dima.
  // Эти пользователи одновременно являются подписчиками, потому что заявка = подписка + pending request.
  await createFriendRequest(maria.id, dima.id)
  await createFriendRequest(sergey.id, dima.id)
  await createFriendRequest(julia.id, dima.id)

  await createPostWithAttachments({
    authorId: dima.id,
    content:
      'Тестирую профильную ленту: в одном посте есть фото, видео, аудио, обычный файл и архив. Отличный набор для проверки UI.',
    files: [
      {
        type: FileAssetType.IMAGE,
        url: '/seed/wine-photo.jpg',
        thumbnailUrl: '/seed/wine-photo.jpg',
        filename: 'wine-photo.jpg',
        mimeType: 'image/jpeg',
        sizeBytes: 420000,
        width: 1200,
        height: 800,
      },
      {
        type: FileAssetType.VIDEO,
        url: '/seed/tasting-video.mp4',
        thumbnailUrl: '/seed/tasting-video-preview.jpg',
        filename: 'tasting-video.mp4',
        mimeType: 'video/mp4',
        sizeBytes: 2400000,
        duration: 42,
      },
      {
        type: FileAssetType.AUDIO,
        url: '/seed/podcast-audio.mp3',
        filename: 'podcast-audio.mp3',
        mimeType: 'audio/mpeg',
        sizeBytes: 980000,
        duration: 86,
      },
      {
        type: FileAssetType.FILE,
        url: '/seed/tasting-notes.pdf',
        filename: 'tasting-notes.pdf',
        mimeType: 'application/pdf',
        sizeBytes: 310000,
      },
      {
        type: FileAssetType.ARCHIVE,
        url: '/seed/photos-archive.zip',
        filename: 'photos-archive.zip',
        mimeType: 'application/zip',
        sizeBytes: 760000,
      },
    ],
  })

  await createPostWithAttachments({
    authorId: olga.id,
    content:
      'Нашла классное сочетание: лёгкое красное вино, паста и немного выдержанного сыра.',
    files: [
      {
        type: FileAssetType.IMAGE,
        url: '/seed/olga-dinner.jpg',
        thumbnailUrl: '/seed/olga-dinner.jpg',
        filename: 'olga-dinner.jpg',
        mimeType: 'image/jpeg',
        sizeBytes: 510000,
        width: 1200,
        height: 900,
      },
    ],
  })

  await createPostWithAttachments({
    authorId: andrey.id,
    content:
      'Добавил в коллекцию редкий ром. Позже сделаю полноценный обзор с заметками.',
    files: [
      {
        type: FileAssetType.FILE,
        url: '/seed/rum-review.pdf',
        filename: 'rum-review.pdf',
        mimeType: 'application/pdf',
        sizeBytes: 280000,
      },
    ],
  })

  await createPostWithAttachments({
    authorId: kate.id,
    content:
      'Мини-влог из поездки: дегустация, атмосфера и немного музыки на фоне.',
    files: [
      {
        type: FileAssetType.VIDEO,
        url: '/seed/kate-trip.mp4',
        thumbnailUrl: '/seed/kate-trip-preview.jpg',
        filename: 'kate-trip.mp4',
        mimeType: 'video/mp4',
        sizeBytes: 3200000,
        duration: 58,
      },
      {
        type: FileAssetType.AUDIO,
        url: '/seed/kate-audio-note.mp3',
        filename: 'kate-audio-note.mp3',
        mimeType: 'audio/mpeg',
        sizeBytes: 650000,
        duration: 35,
      },
    ],
  })

  await createPostWithAttachments({
    authorId: maria.id,
    content:
      'Сегодня сравнивала два бордо. Одно оказалось мягче, второе — интереснее по послевкусию.',
    files: [
      {
        type: FileAssetType.IMAGE,
        url: '/seed/bordeaux-comparison.jpg',
        thumbnailUrl: '/seed/bordeaux-comparison.jpg',
        filename: 'bordeaux-comparison.jpg',
        mimeType: 'image/jpeg',
        sizeBytes: 470000,
        width: 1200,
        height: 800,
      },
    ],
  })

  await createPostWithAttachments({
    authorId: sergey.id,
    content:
      'Короткая заметка про крепкий релиз недели. Аромат мощный, но вкус неожиданно спокойный.',
    files: [
      {
        type: FileAssetType.FILE,
        url: '/seed/strong-release-notes.pdf',
        filename: 'strong-release-notes.pdf',
        mimeType: 'application/pdf',
        sizeBytes: 190000,
      },
    ],
  })


  await createDirectChatWithMessages({
    firstUserId: dima.id,
    secondUserId: maria.id,
    messages: [
      { senderId: maria.id, content: 'Алексей, добрый день! Спасибо за рекомендацию вина, оно действительно великолепное.', minutesAgo: 80, pinned: true },
      { senderId: dima.id, content: 'Мария, привет! Рад, что вам понравилось. Могу порекомендовать ещё несколько вариантов.', minutesAgo: 70 },
      { senderId: maria.id, content: 'Буду очень благодарна! Особенно интересуют белые вина для летних вечеров.', minutesAgo: 60 },
      { senderId: dima.id, content: 'Попробуйте Sauvignon Blanc, Chardonnay и Riesling. Они хорошо подойдут для тёплых вечеров.', minutesAgo: 50, parentIndex: 2 },
    ],
  })

  await createDirectChatWithMessages({
    firstUserId: dima.id,
    secondUserId: sergey.id,
    messages: [
      { senderId: sergey.id, content: 'Да, конечно, давайте попробуем новый формат дегустации.', minutesAgo: 24 * 60 },
      { senderId: dima.id, content: 'Окей, я подготовлю список бутылок и заметки.', minutesAgo: 23 * 60 },
    ],
  })

  await createGroupChatWithMessages({
    title: 'Wine Lovers Club',
    ownerId: dima.id,
    adminIds: [maria.id],
    memberIds: [sergey.id, kate.id, andrey.id, olga.id, anna.id],
    messages: [
      { senderId: dima.id, content: 'Друзья, напоминаю о дегустации в пятницу. Это сообщение закрепляю.', minutesAgo: 3 * 24 * 60, pinned: true },
      { senderId: maria.id, content: 'Я подготовлю подборку белых вин и короткое описание к каждому.', minutesAgo: 2 * 24 * 60, pinned: true },
      {
        senderId: kate.id,
        content: 'Добавляю фото с прошлой дегустации для вдохновения.',
        minutesAgo: 24 * 60,
        file: {
          type: FileAssetType.IMAGE,
          url: '/seed/group-wine-photo.jpg',
          thumbnailUrl: '/seed/group-wine-photo.jpg',
          filename: 'group-wine-photo.jpg',
          mimeType: 'image/jpeg',
          sizeBytes: 520000,
          width: 1200,
          height: 800,
        },
      },
      {
        senderId: andrey.id,
        content: 'Я скину свои заметки PDF, там есть хорошая таблица ароматов.',
        minutesAgo: 22 * 60,
        file: {
          type: FileAssetType.FILE,
          url: '/seed/aroma-table.pdf',
          filename: 'aroma-table.pdf',
          mimeType: 'application/pdf',
          sizeBytes: 260000,
        },
      },
      {
        senderId: olga.id,
        content: 'Записала короткое аудио с идеями для закусок.',
        minutesAgo: 20 * 60,
        file: {
          type: FileAssetType.AUDIO,
          url: '/seed/snacks-ideas.mp3',
          filename: 'snacks-ideas.mp3',
          mimeType: 'audio/mpeg',
          sizeBytes: 740000,
          duration: 44,
        },
      },
    ],
  })

  console.log('Seed completed.')
  console.log(`Main user email: ${dima.email}`)
  console.log(`Main user password: ${defaultPassword}`)
}

main()
  .catch((error) => {
    console.error(error)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })