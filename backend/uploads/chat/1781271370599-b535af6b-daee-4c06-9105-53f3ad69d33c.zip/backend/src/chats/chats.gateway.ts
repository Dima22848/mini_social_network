import {
  ConnectedSocket,
  MessageBody,
  OnGatewayConnection,
  OnGatewayDisconnect,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
  WsException,
} from '@nestjs/websockets'
import { Server, Socket } from 'socket.io'
import { TokenService } from '../auth/token.service'
import { PrismaService } from '../prisma/prisma.service'
import { ChatsService } from './chats.service'
import { CreateMessageDto } from './dto/create-message.dto'

type AuthedSocket = Socket & {
  data: {
    user?: {
      id: string
      email: string
      username: string
      sessionId: string
    }
  }
}

@WebSocketGateway({
  namespace: 'chats',
  cors: {
    origin: process.env.CLIENT_URL,
    credentials: true,
  },
})
export class ChatsGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server!: Server

  constructor(
    private readonly tokenService: TokenService,
    private readonly prisma: PrismaService,
    private readonly chatsService: ChatsService
  ) {}

  async handleConnection(socket: AuthedSocket) {
    const token = this.getTokenFromSocket(socket)

    if (!token) {
      socket.disconnect(true)
      return
    }

    try {
      const payload = this.tokenService.verifyAccessToken(token)
      const session = await this.prisma.session.findUnique({
        where: { id: payload.sessionId },
        select: { id: true, userId: true, revokedAt: true, expiresAt: true },
      })

      if (!session || session.userId !== payload.sub || session.revokedAt || session.expiresAt < new Date()) {
        socket.disconnect(true)
        return
      }

      socket.data.user = {
        id: payload.sub,
        email: payload.email,
        username: payload.username,
        sessionId: payload.sessionId,
      }

      socket.join(`user:${payload.sub}`)

      const chatIds = await this.chatsService.getUserChatIds(payload.sub)
      for (const chatId of chatIds) {
        socket.join(`chat:${chatId}`)
      }

      this.server.emit('presence:changed', {
        userId: payload.sub,
        isOnline: true,
        lastSeenAt: new Date().toISOString(),
      })
    } catch {
      socket.disconnect(true)
    }
  }

  async handleDisconnect(socket: AuthedSocket) {
    const user = socket.data.user

    if (!user) {
      return
    }

    await this.prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    })

    this.server.emit('presence:changed', {
      userId: user.id,
      isOnline: false,
      lastSeenAt: new Date().toISOString(),
    })
  }

  @SubscribeMessage('chat:join')
  async joinChat(@ConnectedSocket() socket: AuthedSocket, @MessageBody() body: { chatId: string }) {
    const user = this.requireSocketUser(socket)
    await this.chatsService.requireMember(body.chatId, user.id)
    socket.join(`chat:${body.chatId}`)
    return { success: true }
  }

  @SubscribeMessage('message:send')
  async sendMessage(
    @ConnectedSocket() socket: AuthedSocket,
    @MessageBody() body: CreateMessageDto & { chatId: string },
  ) {
    const user = this.requireSocketUser(socket)
    const message = await this.chatsService.createMessage(user.id, body.chatId, body)

    this.server.to(`chat:${body.chatId}`).emit('message:new', message)
    this.server.to(`chat:${body.chatId}`).emit('chat:updated', {
      chatId: body.chatId,
      lastMessage: message,
    })

    return message
  }

  @SubscribeMessage('message:react')
  async react(
    @ConnectedSocket() socket: AuthedSocket,
    @MessageBody() body: { messageId: string; emoji: '👍' | '👎' },
  ) {
    const user = this.requireSocketUser(socket)
    const message = await this.chatsService.toggleReaction(user.id, body.messageId, body.emoji)
    this.server.to(`chat:${message.chatId}`).emit('message:updated', message)
    return message
  }

  @SubscribeMessage('message:read')
  async read(
    @ConnectedSocket() socket: AuthedSocket,
    @MessageBody() body: { chatId: string; messageId?: string },
  ) {
    const user = this.requireSocketUser(socket)
    const result = await this.chatsService.markAsRead(user.id, body.chatId, body.messageId)

    this.server.to(`chat:${body.chatId}`).emit('message:read', {
      chatId: body.chatId,
      messageId: body.messageId,
      userId: user.id,
      readAt: new Date().toISOString(),
    })

    return result
  }

  @SubscribeMessage('typing')
  async typing(
    @ConnectedSocket() socket: AuthedSocket,
    @MessageBody() body: { chatId: string; isTyping: boolean },
  ) {
    const user = this.requireSocketUser(socket)
    await this.chatsService.requireMember(body.chatId, user.id)

    socket.to(`chat:${body.chatId}`).emit('typing', {
      chatId: body.chatId,
      user: {
        id: user.id,
        username: user.username,
      },
      isTyping: body.isTyping,
    })

    return { success: true }
  }

  private getTokenFromSocket(socket: Socket) {
    const tokenFromAuth = socket.handshake.auth?.accessToken

    if (typeof tokenFromAuth === 'string') {
      return tokenFromAuth
    }

    const authorization = socket.handshake.headers.authorization

    if (authorization?.startsWith('Bearer ')) {
      return authorization.slice('Bearer '.length)
    }

    return null
  }

  private requireSocketUser(socket: AuthedSocket) {
    const user = socket.data.user

    if (!user) {
      throw new WsException('Unauthorized')
    }

    return user
  }
}
