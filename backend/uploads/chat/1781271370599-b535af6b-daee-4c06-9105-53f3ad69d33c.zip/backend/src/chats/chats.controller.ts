import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common'
import { FileAssetType } from '@prisma/client'
import { AccessTokenGuard } from '../auth/guards/access-token.guard'
import { CurrentUser } from '../auth/decorators/current-user.decorator'
import type { CurrentUserPayload } from '../auth/types/current-user-payload.type'
import { ChatsService } from './chats.service'
import { ChatsQueryDto } from './dto/chats-query.dto'
import { CreateGroupChatDto } from './dto/create-group-chat.dto'
import { CreateMessageDto } from './dto/create-message.dto'
import { ToggleMessageReactionDto } from './dto/toggle-message-reaction.dto'
import { UpdateMemberRoleDto } from './dto/update-member-role.dto'
import { ToggleChatNotificationsDto } from './dto/toggle-chat-notifications.dto'
import { InviteChatMembersDto } from './dto/invite-chat-members.dto'

@UseGuards(AccessTokenGuard)
@Controller('chats')
export class ChatsController {
  constructor(private readonly chatsService: ChatsService) {}

  @Get()
  listChats(@CurrentUser() user: CurrentUserPayload, @Query() query: ChatsQueryDto) {
    return this.chatsService.listChats(user.id, query)
  }

  @Get(':chatId')
  getChat(@CurrentUser() user: CurrentUserPayload, @Param('chatId') chatId: string) {
    return this.chatsService.getChat(user.id, chatId)
  }

  @Get(':chatId/messages')
  getMessages(@CurrentUser() user: CurrentUserPayload, @Param('chatId') chatId: string) {
    return this.chatsService.getMessages(user.id, chatId)
  }

  @Get(':chatId/pinned')
  getPinnedMessages(@CurrentUser() user: CurrentUserPayload, @Param('chatId') chatId: string) {
    return this.chatsService.getPinnedMessages(user.id, chatId)
  }

  @Get(':chatId/members')
  getMembers(@CurrentUser() user: CurrentUserPayload, @Param('chatId') chatId: string) {
    return this.chatsService.getMembers(user.id, chatId)
  }

  @Get(':chatId/attachments')
  getAttachments(
    @CurrentUser() user: CurrentUserPayload,
    @Param('chatId') chatId: string,
    @Query('type') type?: FileAssetType,
  ) {
    return this.chatsService.getAttachments(user.id, chatId, type)
  }

  @Post('direct/:targetUserId')
  createDirectChat(
    @CurrentUser() user: CurrentUserPayload,
    @Param('targetUserId') targetUserId: string,
  ) {
    return this.chatsService.createDirectChat(user.id, targetUserId)
  }

  @Post('groups')
  createGroupChat(@CurrentUser() user: CurrentUserPayload, @Body() dto: CreateGroupChatDto) {
    return this.chatsService.createGroupChat(user.id, dto)
  }

  @Post(':chatId/messages')
  createMessage(
    @CurrentUser() user: CurrentUserPayload,
    @Param('chatId') chatId: string,
    @Body() dto: CreateMessageDto,
  ) {
    return this.chatsService.createMessage(user.id, chatId, dto)
  }

  @Post(':chatId/read')
  markAsRead(
    @CurrentUser() user: CurrentUserPayload,
    @Param('chatId') chatId: string,
    @Body() body: { messageId?: string },
  ) {
    return this.chatsService.markAsRead(user.id, chatId, body.messageId)
  }

  @Post(':chatId/messages/:messageId/reactions/toggle')
  toggleReaction(
    @CurrentUser() user: CurrentUserPayload,
    @Param('messageId') messageId: string,
    @Body() dto: ToggleMessageReactionDto,
  ) {
    return this.chatsService.toggleReaction(user.id, messageId, dto.emoji)
  }

  @Post(':chatId/messages/:messageId/pin')
  pinMessage(
    @CurrentUser() user: CurrentUserPayload,
    @Param('chatId') chatId: string,
    @Param('messageId') messageId: string,
  ) {
    return this.chatsService.pinMessage(user.id, chatId, messageId)
  }

  @Post(':chatId/messages/:messageId/unpin')
  unpinMessage(
    @CurrentUser() user: CurrentUserPayload,
    @Param('chatId') chatId: string,
    @Param('messageId') messageId: string,
  ) {
    return this.chatsService.unpinMessage(user.id, chatId, messageId)
  }

  @Post(':chatId/members/invite')
  inviteMembers(
    @CurrentUser() user: CurrentUserPayload,
    @Param('chatId') chatId: string,
    @Body() dto: InviteChatMembersDto,
  ) {
    return this.chatsService.inviteMembers(user.id, chatId, dto)
  }

  @Patch(':chatId/notifications')
  toggleNotifications(
    @CurrentUser() user: CurrentUserPayload,
    @Param('chatId') chatId: string,
    @Body() dto: ToggleChatNotificationsDto,
  ) {
    return this.chatsService.toggleNotifications(user.id, chatId, dto.enabled)
  }

  @Patch(':chatId/members/:targetUserId/role')
  updateMemberRole(
    @CurrentUser() user: CurrentUserPayload,
    @Param('chatId') chatId: string,
    @Param('targetUserId') targetUserId: string,
    @Body() dto: UpdateMemberRoleDto,
  ) {
    return this.chatsService.updateMemberRole(user.id, chatId, targetUserId, dto.role)
  }

  @Delete(':chatId')
  leaveOrDeleteChat(@CurrentUser() user: CurrentUserPayload, @Param('chatId') chatId: string) {
    return this.chatsService.leaveOrDeleteChat(user.id, chatId)
  }

  @Delete(':chatId/members/:targetUserId')
  removeMember(
    @CurrentUser() user: CurrentUserPayload,
    @Param('chatId') chatId: string,
    @Param('targetUserId') targetUserId: string,
  ) {
    return this.chatsService.removeMember(user.id, chatId, targetUserId)
  }

  @Delete(':chatId/messages/:messageId')
  deleteMessage(
    @CurrentUser() user: CurrentUserPayload,
    @Param('chatId') chatId: string,
    @Param('messageId') messageId: string,
  ) {
    return this.chatsService.deleteMessage(user.id, chatId, messageId)
  }
}
