import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common'
import {
  ChatMemberRole,
  ChatType,
  FileAssetStatus,
  FileAssetType,
  MessageType,
  Prisma,
} from '@prisma/client'
import { PrismaService } from '../prisma/prisma.service'
import { CreateGroupChatDto } from './dto/create-group-chat.dto'
import { CreateMessageDto } from './dto/create-message.dto'
import { ChatsQueryDto } from './dto/chats-query.dto'
import { InviteChatMembersDto } from './dto/invite-chat-members.dto'

const userSelect = {
  id: true,
  username: true,
  email: true,
  lastLoginAt: true,
  profile: {
    select: {
      avatarUrl: true,
    },
  },
} satisfies Prisma.UserSelect

const messageInclude = {
  sender: { select: userSelect },
  parent: {
    select: {
      id: true,
      content: true,
      sender: { select: userSelect },
    },
  },
  attachments: {
    include: {
      file: true,
    },
  },
  reactions: {
    include: {
      user: { select: userSelect },
    },
  },
  reads: {
    include: {
      user: { select: userSelect },
    },
  },
} satisfies Prisma.MessageInclude

const chatInclude = {
  members: {
    where: { leftAt: null },
    include: {
      user: { select: userSelect },
    },
    orderBy: [{ role: 'asc' as const }, { joinedAt: 'asc' as const }],
  },
  messages: {
    where: { deletedAt: null },
    orderBy: { createdAt: 'desc' as const },
    take: 1,
    include: messageInclude,
  },
} satisfies Prisma.ChatInclude

@Injectable()
export class ChatsService {
  constructor(private readonly prisma: PrismaService) {}

  async listChats(userId: string, query: ChatsQueryDto) {
    const page = query.page ?? 1
    const limit = query.limit ?? 20
    const search = query.search?.trim()
    const searchIn = query.searchIn ?? 'all'

    const searchWhere: Prisma.ChatWhereInput[] = []

    if (search && searchIn !== 'messages') {
      searchWhere.push({
        OR: [
          { title: { contains: search, mode: 'insensitive' } },
          {
            members: {
              some: {
                leftAt: null,
                user: { username: { contains: search, mode: 'insensitive' } },
              },
            },
          },
        ],
      })
    }

    if (search && searchIn !== 'nicknames') {
      searchWhere.push({
        messages: {
          some: {
            deletedAt: null,
            content: { contains: search, mode: 'insensitive' },
          },
        },
      })
    }

    const where: Prisma.ChatWhereInput = {
      deletedAt: null,
      members: {
        some: {
          userId,
          leftAt: null,
        },
      },
      ...(search && searchWhere.length > 0 ? { OR: searchWhere } : {}),
    }

    const [items, total] = await this.prisma.$transaction([
      this.prisma.chat.findMany({
        where,
        include: chatInclude,
        orderBy: [{ lastMessageAt: 'desc' }, { updatedAt: 'desc' }],
        skip: (page - 1) * limit,
        take: limit,
      }),
      this.prisma.chat.count({ where }),
    ])

    const matchedMessageMap = new Map<string, Prisma.MessageGetPayload<{ include: typeof messageInclude }>>()

    if (search && searchIn !== 'nicknames' && items.length > 0) {
      const matchedMessages = await this.prisma.message.findMany({
        where: {
          chatId: { in: items.map((chat) => chat.id) },
          deletedAt: null,
          content: { contains: search, mode: 'insensitive' },
        },
        include: messageInclude,
        orderBy: { createdAt: 'desc' },
      })

      for (const message of matchedMessages) {
        if (!matchedMessageMap.has(message.chatId)) {
          matchedMessageMap.set(message.chatId, message)
        }
      }
    }

    return {
      items: items.map((chat) => this.mapChat(chat, userId, matchedMessageMap.get(chat.id))),
      meta: {
        page,
        limit,
        total,
        totalPages: Math.max(1, Math.ceil(total / limit)),
      },
    }
  }

  async getChat(userId: string, chatId: string) {
    await this.requireMember(chatId, userId)

    const chat = await this.prisma.chat.findUnique({
      where: { id: chatId },
      include: chatInclude,
    })

    if (!chat || chat.deletedAt) {
      throw new NotFoundException('Chat not found')
    }

    return this.mapChat(chat, userId)
  }

  async getMessages(userId: string, chatId: string) {
    await this.requireMember(chatId, userId)

    const messages = await this.prisma.message.findMany({
      where: { chatId, deletedAt: null },
      include: messageInclude,
      orderBy: { createdAt: 'asc' },
      take: 100,
    })

    return {
      items: messages.map((message) => this.mapMessage(message)),
    }
  }

  async getPinnedMessages(userId: string, chatId: string) {
    await this.requireMember(chatId, userId)

    const messages = await this.prisma.message.findMany({
      where: { chatId, deletedAt: null, pinnedAt: { not: null } },
      include: messageInclude,
      orderBy: { pinnedAt: 'desc' },
      take: 20,
    })

    return {
      items: messages.map((message) => this.mapMessage(message)),
    }
  }

  async getMembers(userId: string, chatId: string) {
    await this.requireMember(chatId, userId)

    const members = await this.prisma.chatMember.findMany({
      where: { chatId, leftAt: null },
      include: { user: { select: userSelect } },
      orderBy: [{ role: 'asc' }, { joinedAt: 'asc' }],
    })

    return { items: members.map((member) => this.mapMember(member)) }
  }

  async getAttachments(userId: string, chatId: string, type?: FileAssetType) {
    await this.requireMember(chatId, userId)

    const attachments = await this.prisma.messageAttachment.findMany({
      where: {
        message: { chatId, deletedAt: null },
        ...(type ? { file: { is: { type } } } : {}),
      },
      include: {
        file: true,
        message: { include: { sender: { select: userSelect } } },
      },
      orderBy: { createdAt: 'desc' },
      take: 80,
    })

    return {
      items: attachments.map((attachment) => ({
        id: attachment.id,
        messageId: attachment.messageId,
        createdAt: attachment.createdAt,
        sender: attachment.message.sender ? this.mapUser(attachment.message.sender) : null,
        file: attachment.file,
      })),
    }
  }

  async createDirectChat(currentUserId: string, targetUserId: string) {
    if (currentUserId === targetUserId) {
      throw new ForbiddenException('Cannot create direct chat with yourself')
    }

    const directKey = [currentUserId, targetUserId].sort().join(':')

    const chat = await this.prisma.chat.upsert({
      where: { directKey },
      update: { deletedAt: null },
      create: {
        type: ChatType.DIRECT,
        directKey,
        createdById: currentUserId,
        members: {
          create: [
            { userId: currentUserId, role: ChatMemberRole.OWNER },
            { userId: targetUserId, role: ChatMemberRole.MEMBER },
          ],
        },
      },
      include: chatInclude,
    })

    return this.mapChat(chat, currentUserId)
  }

  async createGroupChat(userId: string, dto: CreateGroupChatDto) {
    const title = dto.title.trim()
    const uniqueMemberIds = [...new Set(dto.memberIds.filter((id) => id !== userId))]

    if (!title) {
      throw new BadRequestException('Укажи название группового чата')
    }

    if (uniqueMemberIds.length === 0) {
      throw new BadRequestException('Выбери хотя бы одного участника')
    }

    const existingMembers = await this.prisma.user.findMany({
      where: {
        id: { in: uniqueMemberIds },
        deletedAt: null,
      },
      select: { id: true },
    })

    if (existingMembers.length !== uniqueMemberIds.length) {
      throw new BadRequestException('Один или несколько выбранных пользователей не найдены')
    }

    const chat = await this.prisma.chat.create({
      data: {
        type: ChatType.GROUP,
        title,
        avatarUrl: dto.avatarUrl ?? null,
        createdById: userId,
        members: {
          create: [
            { userId, role: ChatMemberRole.OWNER },
            ...uniqueMemberIds.map((memberId) => ({
              userId: memberId,
              role: ChatMemberRole.MEMBER,
            })),
          ],
        },
      },
      include: chatInclude,
    })

    return this.mapChat(chat, userId)
  }

  async inviteMembers(userId: string, chatId: string, dto: InviteChatMembersDto) {
    const currentMember = await this.requireOwnerOrAdmin(chatId, userId)
    const uniqueMemberIds = [...new Set(dto.memberIds.filter((id) => id !== userId))]

    if (uniqueMemberIds.length === 0) {
      throw new BadRequestException('Выбери хотя бы одного участника')
    }

    const chat = await this.prisma.chat.findUnique({
      where: { id: chatId },
      select: { id: true, type: true, deletedAt: true },
    })

    if (!chat || chat.deletedAt) {
      throw new NotFoundException('Chat not found')
    }

    if (chat.type !== ChatType.GROUP) {
      throw new BadRequestException('Приглашать участников можно только в групповой чат')
    }

    const users = await this.prisma.user.findMany({
      where: { id: { in: uniqueMemberIds }, deletedAt: null },
      select: { id: true },
    })

    if (users.length !== uniqueMemberIds.length) {
      throw new BadRequestException('Один или несколько выбранных пользователей не найдены')
    }

    const allowedIds = await this.getInvitableUserIds(userId, uniqueMemberIds)

    if (allowedIds.size !== uniqueMemberIds.length) {
      throw new BadRequestException('Можно приглашать только друзей, подписчиков или пользователей из твоих подписок')
    }

    const existingMembers = await this.prisma.chatMember.findMany({
      where: { chatId, userId: { in: uniqueMemberIds } },
    })
    const existingMemberByUserId = new Map(existingMembers.map((member) => [member.userId, member]))
    const now = new Date()

    await this.prisma.$transaction(async (tx) => {
      for (const memberId of uniqueMemberIds) {
        const existingMember = existingMemberByUserId.get(memberId)

        if (existingMember && !existingMember.leftAt) {
          continue
        }

        if (existingMember) {
          await tx.chatMember.update({
            where: { id: existingMember.id },
            data: {
              role: ChatMemberRole.MEMBER,
              leftAt: null,
              joinedAt: now,
              notificationsEnabled: true,
            },
          })
        } else {
          await tx.chatMember.create({
            data: {
              chatId,
              userId: memberId,
              role: ChatMemberRole.MEMBER,
              joinedAt: now,
            },
          })
        }

        await tx.chatInvite.upsert({
          where: { chatId_invitedUserId: { chatId, invitedUserId: memberId } },
          create: {
            chatId,
            invitedById: currentMember.userId,
            invitedUserId: memberId,
          },
          update: {
            invitedById: currentMember.userId,
          },
        })
      }

      await tx.chat.update({
        where: { id: chatId },
        data: { updatedAt: now },
      })
    })

    return this.getMembers(userId, chatId)
  }

  async createMessage(userId: string, chatId: string, dto: CreateMessageDto) {
    await this.requireMember(chatId, userId)

    if (!dto.content?.trim() && (!dto.attachments || dto.attachments.length === 0)) {
      throw new ForbiddenException('Message cannot be empty')
    }

    const message = await this.prisma.$transaction(async (tx) => {
      const created = await tx.message.create({
        data: {
          chatId,
          senderId: userId,
          content: dto.content?.trim() || null,
          parentId: dto.parentId || null,
          type: dto.attachments?.length
            ? dto.content?.trim()
              ? MessageType.TEXT_WITH_MEDIA
              : MessageType.MEDIA
            : MessageType.TEXT,
        },
      })

      if (dto.attachments?.length) {
        for (const attachment of dto.attachments) {
          const file = await tx.fileAsset.create({
            data: {
              uploadedById: userId,
              type: attachment.type,
              status: FileAssetStatus.READY,
              url: attachment.url,
              thumbnailUrl: attachment.thumbnailUrl ?? null,
              filename: attachment.filename ?? 'attachment',
              mimeType: attachment.mimeType ?? 'application/octet-stream',
            },
          })

          await tx.messageAttachment.create({
            data: { messageId: created.id, fileId: file.id },
          })
        }
      }

      await tx.chat.update({
        where: { id: chatId },
        data: { lastMessageId: created.id, lastMessageAt: created.createdAt },
      })

      await tx.messageRead.upsert({
        where: { messageId_userId: { messageId: created.id, userId } },
        update: { readAt: new Date() },
        create: { messageId: created.id, userId },
      })

      return tx.message.findUniqueOrThrow({
        where: { id: created.id },
        include: messageInclude,
      })
    })

    return this.mapMessage(message)
  }

  async toggleReaction(userId: string, messageId: string, emoji: '👍' | '👎' | '🔥' | '❤️' | '😡') {
    const message = await this.prisma.message.findUnique({
      where: { id: messageId },
      select: { id: true, chatId: true, deletedAt: true },
    })

    if (!message || message.deletedAt) {
      throw new NotFoundException('Message not found')
    }

    await this.requireMember(message.chatId, userId)

    const existing = await this.prisma.messageReaction.findFirst({
      where: { messageId, userId },
    })

    if (existing?.emoji === emoji) {
      await this.prisma.messageReaction.delete({ where: { id: existing.id } })
    } else if (existing) {
      await this.prisma.messageReaction.update({
        where: { id: existing.id },
        data: { emoji },
      })
    } else {
      await this.prisma.messageReaction.create({ data: { messageId, userId, emoji } })
    }

    const updatedMessage = await this.prisma.message.findUniqueOrThrow({
      where: { id: messageId },
      include: messageInclude,
    })

    return this.mapMessage(updatedMessage)
  }

  async markAsRead(userId: string, chatId: string, messageId?: string) {
    await this.requireMember(chatId, userId)

    const messages = await this.prisma.message.findMany({
      where: {
        chatId,
        deletedAt: null,
        ...(messageId ? { id: messageId } : {}),
      },
      select: { id: true, createdAt: true },
      orderBy: { createdAt: 'asc' },
    })

    if (messages.length === 0) {
      return { success: true }
    }

    const now = new Date()

    await this.prisma.$transaction([
      ...messages.map((message) =>
        this.prisma.messageRead.upsert({
          where: { messageId_userId: { messageId: message.id, userId } },
          update: { readAt: now },
          create: { messageId: message.id, userId, readAt: now },
        }),
      ),
      this.prisma.chatMember.update({
        where: { chatId_userId: { chatId, userId } },
        data: {
          lastReadAt: now,
          lastReadMessageId: messages[messages.length - 1]?.id,
        },
      }),
    ])

    return { success: true }
  }

  async toggleNotifications(userId: string, chatId: string, enabled: boolean) {
    await this.requireMember(chatId, userId)

    await this.prisma.chatMember.update({
      where: { chatId_userId: { chatId, userId } },
      data: { notificationsEnabled: enabled },
    })

    return { success: true }
  }

  async leaveOrDeleteChat(userId: string, chatId: string) {
    const member = await this.requireMember(chatId, userId)
    const chat = await this.prisma.chat.findUniqueOrThrow({ where: { id: chatId } })

    if (chat.type === ChatType.DIRECT) {
      await this.prisma.chat.update({
        where: { id: chatId },
        data: { deletedAt: new Date() },
      })
      return { success: true }
    }

    if (member.role === ChatMemberRole.OWNER) {
      const nextOwner = await this.prisma.chatMember.findFirst({
        where: { chatId, userId: { not: userId }, leftAt: null },
        orderBy: [{ role: 'asc' }, { joinedAt: 'asc' }],
      })

      if (nextOwner) {
        await this.prisma.chatMember.update({
          where: { id: nextOwner.id },
          data: { role: ChatMemberRole.OWNER },
        })
      }
    }

    await this.prisma.chatMember.update({
      where: { chatId_userId: { chatId, userId } },
      data: { leftAt: new Date() },
    })

    return { success: true }
  }

  async updateMemberRole(
    currentUserId: string,
    chatId: string,
    targetUserId: string,
    role: 'ADMIN' | 'MEMBER',
  ) {
    await this.requireOwner(chatId, currentUserId)

    const target = await this.prisma.chatMember.findUnique({
      where: { chatId_userId: { chatId, userId: targetUserId } },
    })

    if (!target || target.leftAt) {
      throw new NotFoundException('Member not found')
    }

    if (target.role === ChatMemberRole.OWNER) {
      throw new ForbiddenException('Cannot change owner role')
    }

    await this.prisma.chatMember.update({
      where: { id: target.id },
      data: { role },
    })

    return this.getMembers(currentUserId, chatId)
  }

  async removeMember(currentUserId: string, chatId: string, targetUserId: string) {
    await this.requireOwnerOrAdmin(chatId, currentUserId)

    const target = await this.prisma.chatMember.findUnique({
      where: { chatId_userId: { chatId, userId: targetUserId } },
    })

    if (!target || target.leftAt) {
      throw new NotFoundException('Member not found')
    }

    if (target.role === ChatMemberRole.OWNER) {
      throw new ForbiddenException('Cannot remove owner')
    }

    await this.prisma.chatMember.update({
      where: { id: target.id },
      data: { leftAt: new Date() },
    })

    return this.getMembers(currentUserId, chatId)
  }

  async deleteMessage(currentUserId: string, chatId: string, messageId: string) {
    const member = await this.requireMember(chatId, currentUserId)
    const message = await this.prisma.message.findUnique({ where: { id: messageId } })

    if (!message || message.chatId !== chatId || message.deletedAt) {
      throw new NotFoundException('Message not found')
    }

    const canDelete =
      message.senderId === currentUserId ||
      member.role === ChatMemberRole.OWNER ||
      member.role === ChatMemberRole.ADMIN

    if (!canDelete) {
      throw new ForbiddenException('Cannot delete this message')
    }

    const updated = await this.prisma.message.update({
      where: { id: messageId },
      data: { deletedAt: new Date(), content: null },
      include: messageInclude,
    })

    return this.mapMessage(updated)
  }

  async pinMessage(currentUserId: string, chatId: string, messageId: string) {
    await this.requireOwnerOrAdmin(chatId, currentUserId)

    const updated = await this.prisma.message.update({
      where: { id: messageId },
      data: { pinnedAt: new Date(), pinnedById: currentUserId },
      include: messageInclude,
    })

    if (updated.chatId !== chatId) {
      throw new NotFoundException('Message not found')
    }

    return this.mapMessage(updated)
  }

  async unpinMessage(currentUserId: string, chatId: string, messageId: string) {
    await this.requireOwnerOrAdmin(chatId, currentUserId)

    const updated = await this.prisma.message.update({
      where: { id: messageId },
      data: { pinnedAt: null, pinnedById: null },
      include: messageInclude,
    })

    if (updated.chatId !== chatId) {
      throw new NotFoundException('Message not found')
    }

    return this.mapMessage(updated)
  }

  async getUserChatIds(userId: string) {
    const members = await this.prisma.chatMember.findMany({
      where: { userId, leftAt: null, chat: { deletedAt: null } },
      select: { chatId: true },
    })

    return members.map((member) => member.chatId)
  }

  async requireMember(chatId: string, userId: string) {
    const member = await this.prisma.chatMember.findUnique({
      where: { chatId_userId: { chatId, userId } },
    })

    if (!member || member.leftAt) {
      throw new ForbiddenException('No access to chat')
    }

    return member
  }

  private async requireOwner(chatId: string, userId: string) {
    const member = await this.requireMember(chatId, userId)

    if (member.role !== ChatMemberRole.OWNER) {
      throw new ForbiddenException('Only owner can do this')
    }

    return member
  }

  private async requireOwnerOrAdmin(chatId: string, userId: string) {
    const member = await this.requireMember(chatId, userId)

    if (member.role !== ChatMemberRole.OWNER && member.role !== ChatMemberRole.ADMIN) {
      throw new ForbiddenException('Only owner or admin can do this')
    }

    return member
  }

  private async getInvitableUserIds(userId: string, targetUserIds: string[]) {
    if (targetUserIds.length === 0) {
      return new Set<string>()
    }

    const friendshipPairs = targetUserIds.map((targetUserId) => {
      const [userAId, userBId] = [userId, targetUserId].sort()

      return { userAId, userBId }
    })

    const [friendships, follows] = await this.prisma.$transaction([
      this.prisma.friendship.findMany({
        where: { OR: friendshipPairs },
        select: { userAId: true, userBId: true },
      }),
      this.prisma.follow.findMany({
        where: {
          OR: [
            { followerId: userId, followingId: { in: targetUserIds } },
            { followingId: userId, followerId: { in: targetUserIds } },
          ],
        },
        select: { followerId: true, followingId: true },
      }),
    ])

    const allowedIds = new Set<string>()

    for (const friendship of friendships) {
      allowedIds.add(friendship.userAId === userId ? friendship.userBId : friendship.userAId)
    }

    for (const follow of follows) {
      allowedIds.add(follow.followerId === userId ? follow.followingId : follow.followerId)
    }

    return allowedIds
  }

  private mapChat(
    chat: Prisma.ChatGetPayload<{ include: typeof chatInclude }>,
    currentUserId: string,
    matchedMessage?: Prisma.MessageGetPayload<{ include: typeof messageInclude }>,
  ) {
    const currentMember = chat.members.find((member) => member.userId === currentUserId)
    const otherMember = chat.members.find((member) => member.userId !== currentUserId)
    const title = chat.type === ChatType.DIRECT ? otherMember?.user.username : chat.title
    const avatarUrl =
      chat.type === ChatType.DIRECT
        ? otherMember?.user.profile?.avatarUrl ?? null
        : chat.avatarUrl

    const lastMessage = chat.messages[0]
    const unreadCount = currentMember?.lastReadAt
      ? chat.messages.filter(
          (message) => message.createdAt > currentMember.lastReadAt! && message.senderId !== currentUserId,
        ).length
      : lastMessage && lastMessage.senderId !== currentUserId
        ? 1
        : 0

    return {
      id: chat.id,
      type: chat.type,
      title: title ?? 'Чат',
      avatarUrl,
      currentUserRole: currentMember?.role ?? 'MEMBER',
      notificationsEnabled: currentMember?.notificationsEnabled ?? true,
      directUser: chat.type === ChatType.DIRECT && otherMember ? this.mapUser(otherMember.user) : null,
      members: chat.members.map((member) => this.mapMember(member)),
      membersCount: chat.members.length,
      unreadCount,
      lastMessage: lastMessage ? this.mapMessage(lastMessage) : null,
      matchedMessage: matchedMessage ? this.mapMessage(matchedMessage) : null,
      lastMessageAt: chat.lastMessageAt,
      createdAt: chat.createdAt,
      updatedAt: chat.updatedAt,
    }
  }

  private mapMember(member: Prisma.ChatMemberGetPayload<{ include: { user: { select: typeof userSelect } } }>) {
    return {
      id: member.id,
      userId: member.userId,
      role: member.role,
      joinedAt: member.joinedAt,
      lastReadAt: member.lastReadAt,
      notificationsEnabled: member.notificationsEnabled,
      user: this.mapUser(member.user),
    }
  }

  private mapMessage(message: Prisma.MessageGetPayload<{ include: typeof messageInclude }>) {
    return {
      id: message.id,
      chatId: message.chatId,
      senderId: message.senderId,
      sender: message.sender ? this.mapUser(message.sender) : null,
      type: message.type,
      content: message.content,
      parentId: message.parentId,
      parent: message.parent
        ? {
            id: message.parent.id,
            content: message.parent.content,
            sender: message.parent.sender ? this.mapUser(message.parent.sender) : null,
          }
        : null,
      attachments: message.attachments.map((attachment) => ({
        id: attachment.id,
        file: attachment.file,
      })),
      reactions: message.reactions.map((reaction) => ({
        id: reaction.id,
        emoji: reaction.emoji,
        userId: reaction.userId,
        user: this.mapUser(reaction.user),
      })),
      reads: message.reads.map((read) => ({
        id: read.id,
        userId: read.userId,
        readAt: read.readAt,
        user: this.mapUser(read.user),
      })),
      pinnedAt: message.pinnedAt,
      pinnedById: message.pinnedById,
      editedAt: message.editedAt,
      deletedAt: message.deletedAt,
      createdAt: message.createdAt,
      updatedAt: message.updatedAt,
    }
  }

  private mapUser(user: Prisma.UserGetPayload<{ select: typeof userSelect }>) {
    return {
      id: user.id,
      username: user.username,
      email: user.email,
      avatarUrl: user.profile?.avatarUrl ?? null,
      lastLoginAt: user.lastLoginAt,
    }
  }
}
