import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common'
import {
  FileAssetStatus,
  Prisma,
  ReactionType,
} from '@prisma/client'
import { PrismaService } from '../prisma/prisma.service'
import { CreateCommentDto } from './dto/create-comment.dto'
import { CreatePostDto } from './dto/create-post.dto'
import { PostsQueryDto } from './dto/posts-query.dto'

@Injectable()
export class PostsService {
  constructor(private readonly prisma: PrismaService) {}

  async createPost(authorId: string, dto: CreatePostDto) {
    const content = dto.content?.trim() ?? ''
    const attachments = dto.attachments ?? []

    if (!content && attachments.length === 0) {
      throw new BadRequestException('Post must contain text or attachments')
    }

    const post = await this.prisma.post.create({
      data: {
        authorId,
        content: content || null,
        attachments: {
          create: attachments.map((attachment, index) => ({
            sortOrder: index,
            file: {
              create: {
                uploadedById: authorId,
                type: attachment.type,
                status: FileAssetStatus.READY,
                url: attachment.url,
                thumbnailUrl: attachment.thumbnailUrl ?? null,
                filename: attachment.filename ?? null,
                mimeType: attachment.mimeType ?? null,
                sizeBytes: attachment.sizeBytes ?? null,
                width: attachment.width ?? null,
                height: attachment.height ?? null,
                duration: attachment.duration ?? null,
              },
            },
          })),
        },
      },
      include: this.getPostInclude(authorId),
    })

    return this.toPostCard(post)
  }

  async getUserPosts(viewerId: string, authorId: string, query: PostsQueryDto) {
    await this.ensureUserExists(authorId)

    const page = query.page ?? 1
    const limit = query.limit ?? 6
    const skip = (page - 1) * limit

    const where = {
      authorId,
      deletedAt: null,
    }

    const [posts, total] = await this.prisma.$transaction([
      this.prisma.post.findMany({
        where,
        include: this.getPostInclude(viewerId),
        orderBy: {
          createdAt: 'desc',
        },
        skip,
        take: limit,
      }),

      this.prisma.post.count({
        where,
      }),
    ])

    return {
      items: posts.map((post) => this.toPostCard(post)),
      pagination: this.getPagination(total, page, limit),
    }
  }

  async getFeedPosts(userId: string, query: PostsQueryDto) {
    const page = query.page ?? 1
    const limit = query.limit ?? 6
    const skip = (page - 1) * limit

    const authorIds = await this.getFeedAuthorIds(userId)

    if (authorIds.length === 0) {
      return {
        items: [],
        pagination: this.getPagination(0, page, limit),
      }
    }

    const where = {
      authorId: {
        in: authorIds,
      },
      deletedAt: null,
    }

    const [posts, total] = await this.prisma.$transaction([
      this.prisma.post.findMany({
        where,
        include: this.getPostInclude(userId),
        orderBy: {
          createdAt: 'desc',
        },
        skip,
        take: limit,
      }),

      this.prisma.post.count({
        where,
      }),
    ])

    return {
      items: posts.map((post) => this.toPostCard(post)),
      pagination: this.getPagination(total, page, limit),
    }
  }

  async togglePostReaction(userId: string, postId: string, type: ReactionType) {
    const post = await this.prisma.post.findFirst({
      where: {
        id: postId,
        deletedAt: null,
      },
      select: {
        id: true,
      },
    })

    if (!post) {
      throw new NotFoundException('Post not found')
    }

    const existingReaction = await this.prisma.postReaction.findUnique({
      where: {
        postId_userId: {
          postId,
          userId,
        },
      },
    })

    await this.prisma.$transaction(async (tx) => {
      if (!existingReaction) {
        await tx.postReaction.create({
          data: {
            postId,
            userId,
            type,
          },
        })

        await tx.post.update({
          where: {
            id: postId,
          },
          data:
            type === ReactionType.LIKE
              ? { likesCount: { increment: 1 } }
              : { dislikesCount: { increment: 1 } },
        })

        return
      }

      if (existingReaction.type === type) {
        await tx.postReaction.delete({
          where: {
            postId_userId: {
              postId,
              userId,
            },
          },
        })

        await tx.post.update({
          where: {
            id: postId,
          },
          data:
            type === ReactionType.LIKE
              ? { likesCount: { decrement: 1 } }
              : { dislikesCount: { decrement: 1 } },
        })

        return
      }

      await tx.postReaction.update({
        where: {
          postId_userId: {
            postId,
            userId,
          },
        },
        data: {
          type,
        },
      })

      await tx.post.update({
        where: {
          id: postId,
        },
        data:
          type === ReactionType.LIKE
            ? {
                likesCount: { increment: 1 },
                dislikesCount: { decrement: 1 },
              }
            : {
                likesCount: { decrement: 1 },
                dislikesCount: { increment: 1 },
              },
      })
    })

    const updatedPost = await this.prisma.post.findUniqueOrThrow({
      where: {
        id: postId,
      },
      include: this.getPostInclude(userId),
    })

    return this.toPostCard(updatedPost)
  }

  async getPostComments(userId: string, postId: string) {
    await this.ensurePostExists(postId)

    const comments = await this.prisma.postComment.findMany({
      where: {
        postId,
        deletedAt: null,
      },
      include: {
        author: {
          include: {
            profile: true,
          },
        },
        reactions: {
          where: {
            userId,
          },
          select: {
            type: true,
          },
        },
      },
      orderBy: {
        createdAt: 'asc',
      },
    })

    return {
      items: comments.map((comment) => this.toCommentCard(comment)),
    }
  }

  async createComment(userId: string, postId: string, dto: CreateCommentDto) {
    const content = dto.content.trim()

    if (!content) {
      throw new BadRequestException('Comment cannot be empty')
    }

    await this.ensurePostExists(postId)

    if (dto.parentId) {
      const parentComment = await this.prisma.postComment.findFirst({
        where: {
          id: dto.parentId,
          postId,
          deletedAt: null,
        },
        select: {
          id: true,
        },
      })

      if (!parentComment) {
        throw new NotFoundException('Parent comment not found')
      }
    }

    await this.prisma.$transaction(async (tx) => {
      await tx.postComment.create({
        data: {
          postId,
          authorId: userId,
          parentId: dto.parentId ?? null,
          content,
        },
      })

      await tx.post.update({
        where: {
          id: postId,
        },
        data: {
          commentsCount: {
            increment: 1,
          },
        },
      })

      if (dto.parentId) {
        await tx.postComment.update({
          where: {
            id: dto.parentId,
          },
          data: {
            repliesCount: {
              increment: 1,
            },
          },
        })
      }
    })

    return this.getPostComments(userId, postId)
  }

  async toggleCommentReaction(
    userId: string,
    commentId: string,
    type: ReactionType,
  ) {
    const comment = await this.prisma.postComment.findFirst({
      where: {
        id: commentId,
        deletedAt: null,
      },
      select: {
        id: true,
        postId: true,
      },
    })

    if (!comment) {
      throw new NotFoundException('Comment not found')
    }

    const existingReaction = await this.prisma.postCommentReaction.findUnique({
      where: {
        commentId_userId: {
          commentId,
          userId,
        },
      },
    })

    await this.prisma.$transaction(async (tx) => {
      if (!existingReaction) {
        await tx.postCommentReaction.create({
          data: {
            commentId,
            userId,
            type,
          },
        })

        await tx.postComment.update({
          where: {
            id: commentId,
          },
          data:
            type === ReactionType.LIKE
              ? { likesCount: { increment: 1 } }
              : { dislikesCount: { increment: 1 } },
        })

        return
      }

      if (existingReaction.type === type) {
        await tx.postCommentReaction.delete({
          where: {
            commentId_userId: {
              commentId,
              userId,
            },
          },
        })

        await tx.postComment.update({
          where: {
            id: commentId,
          },
          data:
            type === ReactionType.LIKE
              ? { likesCount: { decrement: 1 } }
              : { dislikesCount: { decrement: 1 } },
        })

        return
      }

      await tx.postCommentReaction.update({
        where: {
          commentId_userId: {
            commentId,
            userId,
          },
        },
        data: {
          type,
        },
      })

      await tx.postComment.update({
        where: {
          id: commentId,
        },
        data:
          type === ReactionType.LIKE
            ? {
                likesCount: { increment: 1 },
                dislikesCount: { decrement: 1 },
              }
            : {
                likesCount: { decrement: 1 },
                dislikesCount: { increment: 1 },
              },
      })
    })

    return this.getPostComments(userId, comment.postId)
  }

  private getPostInclude(viewerId: string) {
    return {
      author: {
        include: {
          profile: true,
        },
      },
      attachments: {
        include: {
          file: true,
        },
        orderBy: {
          sortOrder: 'asc' as const,
        },
      },
      reactions: {
        where: {
          userId: viewerId,
        },
        select: {
          type: true,
        },
      },
    }
  }

  private toPostCard(post: any) {
    return {
      id: post.id,
      content: post.content,
      likesCount: post.likesCount,
      dislikesCount: post.dislikesCount,
      commentsCount: post.commentsCount,
      createdAt: post.createdAt,
      viewerReaction: post.reactions[0]?.type ?? null,
      author: {
        id: post.author.id,
        username: post.author.username,
        email: post.author.email,
        avatarUrl: post.author.profile?.avatarUrl ?? null,
      },
      attachments: post.attachments.map((attachment: any) => ({
        id: attachment.id,
        sortOrder: attachment.sortOrder,
        file: {
          id: attachment.file.id,
          type: attachment.file.type,
          status: attachment.file.status,
          url: attachment.file.url,
          thumbnailUrl: attachment.file.thumbnailUrl,
          filename: attachment.file.filename,
          mimeType: attachment.file.mimeType,
          sizeBytes: attachment.file.sizeBytes,
          width: attachment.file.width,
          height: attachment.file.height,
          duration: attachment.file.duration,
        },
      })),
    }
  }

  private toCommentCard(comment: any) {
    return {
      id: comment.id,
      postId: comment.postId,
      parentId: comment.parentId,
      content: comment.content,
      likesCount: comment.likesCount,
      dislikesCount: comment.dislikesCount,
      repliesCount: comment.repliesCount,
      createdAt: comment.createdAt,
      viewerReaction: comment.reactions[0]?.type ?? null,
      author: {
        id: comment.author.id,
        username: comment.author.username,
        email: comment.author.email,
        avatarUrl: comment.author.profile?.avatarUrl ?? null,
      },
    }
  }

  private async getFeedAuthorIds(userId: string) {
    const [friendships, follows] = await Promise.all([
      this.prisma.friendship.findMany({
        where: {
          OR: [
            {
              userAId: userId,
            },
            {
              userBId: userId,
            },
          ],
        },
        select: {
          userAId: true,
          userBId: true,
        },
      }),

      this.prisma.follow.findMany({
        where: {
          followerId: userId,
        },
        select: {
          followingId: true,
        },
      }),
    ])

    const authorIds = new Set<string>()

    for (const friendship of friendships) {
      authorIds.add(
        friendship.userAId === userId ? friendship.userBId : friendship.userAId,
      )
    }

    for (const follow of follows) {
      authorIds.add(follow.followingId)
    }

    authorIds.delete(userId)

    return [...authorIds]
  }

  private getPagination(total: number, page: number, limit: number) {
    return {
      page,
      limit,
      total,
      totalPages: Math.max(1, Math.ceil(total / limit)),
    }
  }

  private async ensureUserExists(userId: string) {
    const user = await this.prisma.user.findFirst({
      where: {
        id: userId,
        deletedAt: null,
      },
      select: {
        id: true,
      },
    })

    if (!user) {
      throw new NotFoundException('User not found')
    }
  }

  private async ensurePostExists(postId: string) {
    const post = await this.prisma.post.findFirst({
      where: {
        id: postId,
        deletedAt: null,
      },
      select: {
        id: true,
      },
    })

    if (!post) {
      throw new NotFoundException('Post not found')
    }
  }
}