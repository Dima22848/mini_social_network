import { Body, Controller, Get, Param, Post, Query, UseGuards } from '@nestjs/common'
import { CurrentUser } from '../auth/decorators/current-user.decorator'
import { AccessTokenGuard } from '../auth/guards/access-token.guard'
import type { CurrentUserPayload } from '../auth/types/current-user-payload.type'
import { CreateCommentDto } from './dto/create-comment.dto'
import { CreatePostDto } from './dto/create-post.dto'
import { PostsQueryDto } from './dto/posts-query.dto'
import { ToggleReactionDto } from './dto/toggle-reaction.dto'
import { PostsService } from './posts.service'

@UseGuards(AccessTokenGuard)
@Controller('posts')
export class PostsController {
  constructor(private readonly postsService: PostsService) {}

  @Post()
  createPost(
    @CurrentUser() user: CurrentUserPayload,
    @Body() dto: CreatePostDto,
  ) {
    return this.postsService.createPost(user.id, dto)
  }

  @Get('feed')
  getFeed(
    @CurrentUser() user: CurrentUserPayload,
    @Query() query: PostsQueryDto,
  ) {
    return this.postsService.getFeedPosts(user.id, query)
  }

  @Get('users/:userId')
  getUserPosts(
    @CurrentUser() user: CurrentUserPayload,
    @Param('userId') userId: string,
    @Query() query: PostsQueryDto,
  ) {
    return this.postsService.getUserPosts(user.id, userId, query)
  }

  @Post('comments/:commentId/reactions/toggle')
  toggleCommentReaction(
    @CurrentUser() user: CurrentUserPayload,
    @Param('commentId') commentId: string,
    @Body() dto: ToggleReactionDto,
  ) {
    return this.postsService.toggleCommentReaction(user.id, commentId, dto.type)
  }

  @Post(':postId/reactions/toggle')
  togglePostReaction(
    @CurrentUser() user: CurrentUserPayload,
    @Param('postId') postId: string,
    @Body() dto: ToggleReactionDto,
  ) {
    return this.postsService.togglePostReaction(user.id, postId, dto.type)
  }

  @Get(':postId/comments')
  getPostComments(
    @CurrentUser() user: CurrentUserPayload,
    @Param('postId') postId: string,
  ) {
    return this.postsService.getPostComments(user.id, postId)
  }

  @Post(':postId/comments')
  createComment(
    @CurrentUser() user: CurrentUserPayload,
    @Param('postId') postId: string,
    @Body() dto: CreateCommentDto,
  ) {
    return this.postsService.createComment(user.id, postId, dto)
  }
}