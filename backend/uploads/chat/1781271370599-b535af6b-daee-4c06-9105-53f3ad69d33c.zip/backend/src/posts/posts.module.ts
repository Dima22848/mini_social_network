import { Module } from '@nestjs/common'
import { PostsController } from './posts.controller'
import { PostsService } from './posts.service'
import { TokenService } from 'src/auth/token.service'

@Module({
  controllers: [PostsController],
  providers: [PostsService, TokenService],
})
export class PostsModule {}